import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { extract } from './core/i18/i18n.service';
import { AieslandingPageComponent } from './modules/aieslanding-page/aieslanding-page.component';
import { IndustryComponent } from './modules/industry/industry.component';
// export const APP_ROUTES: Routes = [
//   { 
//     path: 'home', 
//     component: HomeComponent, 
//     data: { title: extract('Home') } 
//   },
//   { 
//     path: 'about', 
//     component: 
//     AboutComponent,  
//     data: { title: extract('About') } 
//   },  
//   { path: '**', redirectTo: 'home', pathMatch: 'full' }
// ];


const appRoutes: Routes = [ 
  { path: '', component: AieslandingPageComponent },
  { path: 'industry-landing', component: IndustryComponent }
 // { path: 'industry-landing/:subSiteName', component: IndustryComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
    ]
})
export class AppRouting {

}
