import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';

import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { RouterModule, PreloadAllModules } from '@angular/router'; 
import { AppRouting } from './app-routing';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IndustryModule } from './modules/industry/industry.module';
import { AieslandingPageModule } from './modules/aieslanding-page/aieslanding-page.module';


/*@NgModule({
  imports: [
    BrowserModule,
    AieslandingPageModule,
    SharedModule,
    IndustryModule,
    HttpModule,
    CoreModule,RouterModule
     // remove these modules from import if you want to lazy load via router
    // AboutModule, // remove these modules from import if you want to lazy load via router
    
    //RouterModule.forRoot(APP_ROUTES, { preloadingStrategy: PreloadAllModules }), // for lazy loading
    //RouterModule.forRoot(APP_ROUTES), 
   ],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})*/
@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    TranslateModule.forRoot(),
    NgbModule.forRoot(),
    BrowserAnimationsModule,
    CoreModule,
    SharedModule,
    AppRouting,
    IndustryModule,
    AieslandingPageModule,
     // remove these modules from import if you want to lazy load via router
    // AboutModule, // remove these modules from import if you want to lazy load via router

    ToastrModule.forRoot({ 
      timeOut: 5000, // number of milliseconds toaster can stay
      positionClass: 'toast-bottom-right', // placement of the toaster
      preventDuplicates: true, // you cannot raise same toaster twice
    }),   
    
    //RouterModule.forRoot(APP_ROUTES, { preloadingStrategy: PreloadAllModules }), // for lazy loading
    //RouterModule.forRoot(APP_ROUTES), 
   ],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
