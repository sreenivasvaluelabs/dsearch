import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
   selector: 'app-accordian',
   templateUrl: './accordian.component.html',
   styleUrls: ['./accordian.component.scss'],
   encapsulation: ViewEncapsulation.None
})
export class AccordianComponent implements OnInit {

   constructor() { }

   ngOnInit() {
   }

}
