import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AieslandingPageComponent } from './aieslanding-page.component';

describe('AieslandingPageComponent', () => {
  let component: AieslandingPageComponent;
  let fixture: ComponentFixture<AieslandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AieslandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AieslandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
