import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aieslanding-page',
  templateUrl: './aieslanding-page.component.html',
  styleUrls: ['./aieslanding-page.component.scss']
})
export class AieslandingPageComponent implements OnInit {

  public industryTabTitle: String;
  public industryDesc: String;
  public industryIsAlternateRow: boolean;
  public toolsAccTabTitle: String;
  public toolsAccDesc: String;
  public toolsAccIsAlternateRow: boolean;
  public otherResourcesTabTitle: String;
  public otherResourcesDesc: String;
  public otherResourcesAlternateRow: boolean;

  loading: Boolean = true;

  constructor() { 

     this.industryTabTitle='Industry Solutions';
     this.industryDesc='Industry Solutions is a portfolio of solutions designed to cover virtually every business communication need across    any industry. AIES is helping businesses tailor their integration strategy to harness the dynamics of their industry. Explore industry-specific integration strategies, solutions applied in key industry sectors.';
     this.industryIsAlternateRow=true;
     this.toolsAccTabTitle='Tools & Acccelators';
     this.toolsAccDesc='Tools & Accelerators are shaped around unique business needs and requirements of specific industry sectors. Explore the various tools that offer solutions and knowledge that drive industry standards and innovations.';
     this.toolsAccIsAlternateRow=false;
     this.otherResourcesTabTitle='Other Resources';
     this.otherResourcesDesc='To help with the research, projects or course preparation, we have put together a list of links containing additional information and guidance.';
     this.otherResourcesAlternateRow=true;

     this.loading = false;
  }

  ngOnInit() {
  }

}
