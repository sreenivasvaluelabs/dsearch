import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeCarouselComponent } from './home-carousel/home-carousel.component';
import { ToolsAcceleratorsComponent } from './tools-accelerators/tools-accelerators.component';
import { AieslandingPageComponent } from './aieslanding-page.component';
import { RootService } from '../../service/_services/root.service';
import { AccordianComponent } from './accordian/accordian.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OtherResourcesComponent } from './other-resources/other-resources.component';
import { IndustrySolutionsComponent } from './industry-solutions/industry-solutions.component';
//import { QuicklinksComponent } from './quicklinks/quicklinks.component';

import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    NgbModule,
    CommonModule,
    SharedModule
  ],
  declarations: [
    HomeCarouselComponent, 
    ToolsAcceleratorsComponent, 
    AieslandingPageComponent,
    AccordianComponent,
    HomeBannerComponent,
    OtherResourcesComponent,
    IndustrySolutionsComponent
    ],
    exports: [AieslandingPageComponent],
    //IndustrySolutionsComponent],
     providers : [RootService]
})
export class AieslandingPageModule { }
