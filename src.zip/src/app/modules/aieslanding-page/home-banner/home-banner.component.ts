import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-home-banner',
   templateUrl: './home-banner.component.html',
   styleUrls: ['./home-banner.component.scss']
})
export class HomeBannerComponent implements OnInit {

   constructor() { }

   ngOnInit() {
   }
   bannerSlide = {
      "title": "Avanade Intelligent Enterprise Solutions",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      "href": "http://avanade.com",
      "imageurl": './assets/images/carousel_01.png'
   }
}
