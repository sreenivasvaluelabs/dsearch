import { Component, OnInit } from '@angular/core';
import * as models from '../../../service/_models'; 
import { RootService } from '../../../service/_services/root.service';


@Component({
   selector: 'app-home-carousel',
   templateUrl: './home-carousel.component.html',
   styleUrls: ['./home-carousel.component.scss']
})
export class HomeCarouselComponent implements OnInit {

    public carouselData : any;
    private promotionData: Array<models.Promotion>;
    
    constructor(private landingSvc : RootService) { 

       this.promotionData = new Array<models.Promotion>();
    }

   ngOnInit() {

        this.landingSvc.GetPromotionlist().subscribe(x => {
        this.carouselData = x;
        this.carouselData = this.mapPormotionData();

        //console.log(this.carouselData);
      });
   }
 
   private mapPormotionData() : Array<models.Promotion> {

        let resultsDD= this.carouselData.d.results;
          // let resultsDD= this.carouselData.value;

           if(resultsDD!=undefined && resultsDD.length>0){
           
            for(let i in resultsDD){
            
              let item=resultsDD[i];				
              
              let imageURL="";
              if(item.Image_x0020_URL !=null )
                imageURL=item.Image_x0020_URL["Description"];
              
              let detailURL="";
              let DetailText="";

              if(item.Know_x0020_More_x0020_Url !=null )
              {
                        DetailText=item.Know_x0020_More_x0020_Url["Description"];
                        detailURL=item.Know_x0020_More_x0020_Url["Url"]; 
              } 
              
              this.promotionData.push({"promotionId":item.ID,"promotionName":item.Title,"imageUrl":imageURL,"description":item.Ava_Description,"knowMoreUrl":detailURL,"knowMoreText":DetailText});
            }           
            return this.promotionData;
       }
  }
}