import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndustrySolutionsComponent } from './industry-solutions.component';

describe('IndustrySolutionsComponent', () => {
  let component: IndustrySolutionsComponent;
  let fixture: ComponentFixture<IndustrySolutionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndustrySolutionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndustrySolutionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
