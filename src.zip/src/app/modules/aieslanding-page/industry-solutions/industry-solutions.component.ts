import { Component, OnInit } from '@angular/core';
import * as models from '../../../service/_models'; 
import { RootService } from '../../../service/_services/root.service';
import { FilterPipe } from '../../../shared/pipes/industry-filter.pipe';

@Component({
  selector: 'app-industry-solutions',
  templateUrl: './industry-solutions.component.html',
  styleUrls: ['./industry-solutions.component.scss'],
  providers : [FilterPipe]
})
export class IndustrySolutionsComponent implements OnInit {

    
tabDetails : any;
private listofIndustries: Array<models.industryGroup>;
private listofSubIndustries: Array<models.SubindustryGroup>;
private industry: Array<models.IndustryDetail>;

tileList : any = [];
tabList : any = [];
private tabWithTilesList : any = [];
industryPipe : any;
tileType : string;
indusrtyCount:number;
allIndustryCount:number;
loading: Boolean = true;

  constructor(private _rootService : RootService) {

        this.listofIndustries = new Array<models.industryGroup>();
        this.listofSubIndustries= Array<models.SubindustryGroup>();
        this.industry= Array<models.IndustryDetail>();

        this.tileType = 'icon';
   }

  ngOnInit() {
    this.loading = true;

    this._rootService.GetIndustryList().subscribe(x => {

            this.tabDetails = x;
            
            this.tabDetails = this.mapIndustryComponentData();

            this.tabList.push({ name : 'All', count :this.allIndustryCount});
            
            //read all tab headers
            this.tabDetails.forEach((x:models.industryGroup) => {
                //adding all tab headers
                this.tabList.push({ name : x.industryGroupName, count : x.industryCount});
                
                //populate tile list
                x.industrySubGroup.forEach((y:models.SubindustryGroup) => {
                    let industriesList = y.industries;
                    industriesList.forEach((z:models.IndustryDetail) => {
                        this.tileList.push({ 
                            title : z.industryName, 
                            subTitle : y.subIndustryGroupName, 
                            description : x.industryGroupName, 
                            imageUrl : z.imageUrl, 
                            tileType : ''
                        });
                    });
                });
            
            });
           this.loading = false; 
        });
    
  }

tabChanged($event: any) {
    this.industryPipe = $event;
  }

private mapIndustryComponentData() : Array<models.industryGroup> {
      //map to industry data
      //let resultsDD = this.tabDetails.d.results;
      let resultsDD = this.tabDetails.value;
   
      let IndustryList = {};
      
      if(resultsDD!=undefined && resultsDD.length>0){
          for(let i in resultsDD)
          {
              
                  let item=resultsDD[i];					   
                  
                  //let metadata=item.Industry_x0020_Solution.results;
                  let metadata=item.Industry_x0020_Solution;
                  
                  let level=metadata[0].Label;
                  level=level.split(":");
                  let level1=level[0];
                  let level2=level[1];
                  let level3=level[2];  

                  let ImageURL="";
                  if(item.Image_x0020_URL !=null )
                      ImageURL=item.Image_x0020_URL["Description"];    
              
                  
                  if(IndustryList[level1] != undefined )
                  {             
                      
                      if(IndustryList[level1][level2] != undefined)
                      {
                          IndustryList[level1][level2][level3]={};
                          IndustryList[level1][level2][level3]["ID"]=item.ID;
                          IndustryList[level1][level2][level3]["Imageurl"]=ImageURL;	
                          IndustryList[level1][level2][level3]["subsiteName"]=item.Subsite_x0020_name;						
                      }
                      else{
                          
                          IndustryList[level1][level2]={};
                          IndustryList[level1][level2][level3]={};
                          IndustryList[level1][level2][level3]["ID"]=item.ID;
                          IndustryList[level1][level2][level3]["Imageurl"]=ImageURL;	
                          IndustryList[level1][level2][level3]["subsiteName"]=item.Subsite_x0020_name;					
                      }							
                  }
                  else
                  {						
                      IndustryList[level1]={};								
                      IndustryList[level1][level2]={};
                      IndustryList[level1][level2][level3]={};
                      IndustryList[level1][level2][level3]["ID"]=item.ID;
                      IndustryList[level1][level2][level3]["Imageurl"]=ImageURL; 
                      IndustryList[level1][level2][level3]["subsiteName"]=item.Subsite_x0020_name;												
                  }
              }//end for

              let keys=Object.keys(IndustryList).length;
              if(keys>0){
                this.indusrtyCount=0;
                this.allIndustryCount=0;	
                  for(let m in IndustryList)
                  {		
                      // All firest level will come	
                      let tmp_values = [];		
                    
                    this.indusrtyCount=0;	

                      let level2=IndustryList[m];			
                      if(level2!=undefined)
                      {	
                         this.listofSubIndustries = new Array<models.SubindustryGroup>(); 
                          for(let l2 in level2)
                          {
                              let level3=level2[l2];
                              if(level3!=undefined)
                              {
                                  this.industry = new Array<models.IndustryDetail>(); 
                                  for(let l3 in level3)
                                  {	
                                        this.indusrtyCount=this.indusrtyCount+1;
                                        this.allIndustryCount=this.allIndustryCount+1	

                                      this.industry.push(new models.IndustryDetail({industryName: l3, industyDetailId: level3[l3].ID,imageUrl:level3[l3].Imageurl,subSiteName:level3[l3].subsiteName}));
                                  }						
                              }
                             // console.log(this.indusrtyCount); // Industry Count will come based on Industry group						
                              this.listofSubIndustries.push(new models.SubindustryGroup({subIndustryGroupName: l2, industries: this.industry})); //key
                          }				
                      }			
                      this.listofIndustries.push(new models.industryGroup({industryGroupName: m, industrySubGroup: this.listofSubIndustries,industryCount:this.indusrtyCount}));
                      //console.log("this.listofIndustries")
                      //console.log(this.listofIndustries);
                  }
                   //console.log(this.allIndustryCount); // ALL Industry Count will come	
                  return this.listofIndustries;
              } //end if
          }//end if
    }
}
