import { Component, OnInit } from '@angular/core';
import { RootService } from '../../../service/_services/index';
import * as models from '../../../service/_models'; 

@Component({
  selector: 'app-other-resources',
  templateUrl: './other-resources.component.html',
  styleUrls: ['./other-resources.component.scss']
})
export class OtherResourcesComponent implements OnInit {

tileList : any = [];
tileType : string;

private otherResources: any;
private otherResourcesData : Array<models.OtherResource>;

  constructor(private _rootService : RootService) { 
    this.tileType = 'graphical';
    this.otherResourcesData = new Array<models.OtherResource>();
  }

  ngOnInit() {

      this._rootService.GetOtherResources().subscribe(x => {
      
      this.otherResources = x;
      this.GetQuickLinksMappedData();
      
      this.otherResourcesData.forEach((x:models.OtherResource) => {
        this.tileList.push({ 
            title : x.menu,
            subTitle : '', 
            description : x.description, 
            imageUrl : x.imageUrl, 
            tileType : this.tileType
        });
      });
    });
  }

private GetQuickLinksMappedData() : void{
    let data = this.otherResources;
    
    //let resultsDD=data.d.results;
    let resultsDD=data.value;
    
    let QuickLinksTemp=[];

    if(resultsDD!=undefined && resultsDD.length>0){
      for(let i in resultsDD){
          let item=resultsDD[i];
          let imageURL="";
          if(item.Image_x0020_URL !=null )
              imageURL=item.Image_x0020_URL["Description"];						
          let URL="";
          if(item.URL !=null )
              URL=item.URL["Description"];
          
          let ParentMenu="";
          if(item.Parent_x0020_Menu.Title != undefined)
              ParentMenu=item.Parent_x0020_Menu.Title;

          // This logic for Other Resourcs 
          if(item.Link_x0020_Type == 'Other Resources')							
              //this.otherResourcesData.push({menu:item.Title,Id:item.ID,parentMenu:ParentMenu,level:item.Level,url:URL,imageUrl:imageURL,description:item.Ava_Description,linkType:item.Link_x0020_Type});
              this.otherResourcesData.push(new models.OtherResource({ menu : item.Title, parentMenu : ParentMenu, level : item.Level, url : URL, imageUrl : imageURL, description : item.Ava_Description, linkType : item.Link_x0020_Type }));
      
         // end of the Other Resources

         // This logic for only Quick Links 
          if(item.Link_x0020_Type == 'Footer Links')
          {						
              if(QuickLinksTemp[ParentMenu] != undefined )
              {							
                  QuickLinksTemp[ParentMenu][item.Title]={};
                  QuickLinksTemp[ParentMenu][item.Title]["ID"]=item.ID;
                  QuickLinksTemp[ParentMenu][item.Title]["URL"]=URL;							                               
              }
              else
              {		
                  if(ParentMenu == '')
                      QuickLinksTemp[item.Title]={};		                                            
              }								
          }					
          // end of the quick Link Logic                 
      }
    }

    let keys=Object.keys(QuickLinksTemp).length;
         
          if(keys>0){
              
             let quickLinks=new Array<models.QuickLinks>();
             let ChildQuickLinks=new Array<models.ChildQuickLink>();
              
             for(let m in QuickLinksTemp)
             {						
                 let ChildQuickLin=QuickLinksTemp[m];			
                 if(ChildQuickLin!=undefined)
                 {	
                     ChildQuickLinks=new Array<models.ChildQuickLink>();
                     
                     for(let cl in ChildQuickLin)
                     {										
                         //ChildQuickLinks.push({QuickLinkName: cl, QuickLinkID:ChildQuickLin[cl].ID,URL:ChildQuickLin[cl].URL}); //key
                         ChildQuickLinks.push(new models.ChildQuickLink({ quickLinkID : ChildQuickLin[cl].ID, quickLinkName : cl, url : ChildQuickLin[cl].URL })); //key
                     }				
                 }			
                 //quickLinks.push({QuickLinkParent: m, QuickLinkChild: ChildQuickLinks});
                 quickLinks.push(new models.QuickLinks({ parentQuickLinkName : m, childQuickLinks : ChildQuickLinks }));
             }
             //console.log(quickLinks);
             this._rootService.quickLinksMapped = quickLinks;

          }

      //assigning service variables so that it can be used anywhere by accessing service variables
      this._rootService.otherResourcesMapped = this.otherResourcesData;
      this.otherResources = this.otherResourcesData;

      //console.log(this.otherResources);

     // console.log("Other resources mapped data");
      //console.log(this._rootService.otherResourcesMapped);
      //console.log("quick links mapped data");
     // console.log(this._rootService.quickLinksMapped);
      
  }
}
