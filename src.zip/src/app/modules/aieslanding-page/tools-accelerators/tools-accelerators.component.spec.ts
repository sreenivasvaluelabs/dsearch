import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolsAcceleratorsComponent } from './tools-accelerators.component';

describe('ToolsAcceleratorsComponent', () => {
  let component: ToolsAcceleratorsComponent;
  let fixture: ComponentFixture<ToolsAcceleratorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolsAcceleratorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolsAcceleratorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
