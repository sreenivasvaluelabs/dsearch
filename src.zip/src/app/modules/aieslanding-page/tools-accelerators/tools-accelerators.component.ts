import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import * as models from '../../../service/_models'; 
import { RootService } from '../../../service/_services/root.service';

@Component({
   selector: 'app-tools-accelerators',
   templateUrl: './tools-accelerators.component.html',
   styleUrls: ['./tools-accelerators.component.scss'],
   encapsulation: ViewEncapsulation.None
})
export class ToolsAcceleratorsComponent implements OnInit {
    
    toolsDetails: any;
    tileList : any = [];
    tileType : string;
    private listofToolsAccelerator: Array<models.ToolsAccelerator>;

   constructor(private _rootService : RootService) { 
       this.tileType = 'icon';
       this.listofToolsAccelerator = new Array<models.ToolsAccelerator>();
   }

   ngOnInit() {

    this._rootService.GetAccecelators().subscribe(x => {
        
        //console.log("Tools & Acc data in ngOnInit...");
        //console.log(x);

            this.toolsDetails = x;
            this.toolsDetails = this.mapToolsComponentData();
            this.toolsDetails.forEach((x: models.ToolsAccelerator) => {
                this.tileList.push({
                    title: x.accelatorName,
                    subTitle: '',
                    description: '',
                    imageUrl: x.imageUrl,
                    tileType: this.tileType
                });
            });
        });

   }

    private mapToolsComponentData(): Array<models.ToolsAccelerator> {
        
        //let resultsDD = this.toolsDetails.d.results;
        let resultsDD = this.toolsDetails.value;

        if (resultsDD != undefined && resultsDD.length > 0) {
            for (let i in resultsDD) {
                let item = resultsDD[i];
                let imageURL = "";
                if (item.Image_x0020_URL != null)
                    imageURL = item.Image_x0020_URL["Url"];
                //this.listofToolsAccelerator.push(new models.ToolsAccelerator({ Id: item.Id, accelatorName: item.accelatorName, imageUrl: item.imageUrl }));
                this.listofToolsAccelerator.push(new models.ToolsAccelerator({ Id: item.ID, accelatorName: item.Accelerator, imageUrl: imageURL }));
            }
           // console.log(this.listofToolsAccelerator);
        }
        return this.listofToolsAccelerator;
    }
}
