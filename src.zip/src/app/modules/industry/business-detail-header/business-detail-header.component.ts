import { Component, OnInit } from '@angular/core';
import { IndustryService } from '../../../service/_services/industry.service';
import * as models from '../../../service/_models'; 

@Component({
  selector: 'app-business-detail-header',
  templateUrl: './business-detail-header.component.html',
  styleUrls: ['./business-detail-header.component.scss']
})
export class BusinessDetailHeaderComponent implements OnInit {

  filteredDetailData: any;
  public businessHeaderDetails: any;

  public businessstrategyDetails: any;
  public businessassestDetails: any;
  public businessaccelaratorDetails: any;
  public businessactivitiesDetails: any;

  area: string;
  type: string;
  owner: string;
  status: string;
  scoping: string;
  description: string;
  name: string;

  constructor(private _industryService : IndustryService) { 

    
  }

  ngOnInit() {
debugger;
        this.businessHeaderDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("03", "");
    
        console.log("this.businessHeaderDetails");
        //console.log(this.businessHeaderDetails);

        let resultsDD = this.businessHeaderDetails.value;
        if (resultsDD != undefined && resultsDD.length > 0) {

          for (let i in resultsDD) {
            let item = resultsDD[i];
            this.area = item.area;
            this.type = item.type;
            this.owner = item.owner;
            this.status = item.status;
            this.scoping = item.scoping;
            this.description= item.description;
            this.name = item.name;
          }
        }
        console.log("this.headerList");


        // this.businessactivitiesDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R01.03.02.01.01.02", "activities");
        // console.log("final.businessactivitiesDetails");
        // console.log(this.businessactivitiesDetails);

        // this.businessstrategyDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("03.02.01", "strategy");
        // console.log("final.strategy");

        // console.log(this.businessstrategyDetails);

        // this.businessassestDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R01.03.02.01.01.02", "assest");
        // console.log("final.businessassestDetails");
        // console.log(this.businessassestDetails);

        // this.businessaccelaratorDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R01.03.02.01.01.02", "accelarator");
        // console.log("final.businessaccelaratorDetails");
        // console.log( this.businessaccelaratorDetails);
          

  }

}
