import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessDetailTilesComponent } from './business-detail-tiles.component';

describe('BusinessDetailTilesComponent', () => {
  let component: BusinessDetailTilesComponent;
  let fixture: ComponentFixture<BusinessDetailTilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessDetailTilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessDetailTilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
