import { Component, OnInit,Input } from '@angular/core';
import { IndustryService } from '../../../service/_services/industry.service';
import * as models from '../../../service/_models';

@Component({
  selector: 'app-business-detail-tiles',
  templateUrl: './business-detail-tiles.component.html',
  styleUrls: ['./business-detail-tiles.component.scss']
})

export class BusinessDetailTilesComponent implements OnInit {
  public listofbusinessactivities: Array<models.BusinessProcessActivities>;
  public listofbusinessStrategyDetailsData: Array<models.BusinessPorcessMapping>;
  public listofassestDetailsData: Array<models.BusinessProcessAssets>;
  public listofaccelaratorDetailsData: Array<models.BusinessPorcessAccelerator>;
  public businessHeaderDetails: any;
  public businessstrategyDetails: any;
  public businessassestDetails: any;
  public businessaccelaratorDetails: any;
  public businessactivitiesDetails: any;
  public businessstrategyDetailscount: number;
  public businessassestDetailscount: number;
  public businessaccelaratorDetailscount: number;
  public businessactivitiesDetailscount: number;
  public vdxFileUrlSrc: string = "";
  tabList : any = [];
  public showTile:any;
  public activitiesCount: number;
  public strategyCount: number;
  public assestsCount: number;
  public accelaratorCount: number;
 
  


  constructor(private _industryService: IndustryService) { 
    this.listofbusinessactivities = new Array<models.BusinessProcessActivities>();
    this.listofbusinessStrategyDetailsData = new Array<models.BusinessPorcessMapping>();
    this.listofassestDetailsData = new Array<models.BusinessProcessAssets>();
    this.listofaccelaratorDetailsData = new Array<models.BusinessPorcessAccelerator>();

        
  }

  ngOnInit() {

       debugger;

    console.log("detail tiles count");

    //Activities 
    this.businessactivitiesDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R01.03.02.01.01.02", "activities");
    console.log("final.businessactivitiesDetails");
    debugger;
    console.log(this.businessactivitiesDetails);
    console.log("activities length");
    console.log(this.businessactivitiesDetails.value.length);
    this.activitiesCount=this.businessactivitiesDetails.value.length;
    if (this.businessactivitiesDetails != undefined && this.businessactivitiesDetails.value.length > 0) {

      for (var _i = 0; _i < this.businessactivitiesDetails.value.length; _i++) {

        let item = this.businessactivitiesDetails.value[_i];
        let Id = item.Id;
        let application = item.application;
        let lane = item.lane;
        let recordingType = item.recordingType;
        let activityType = item.activityType;
        let activityName = item.activityName;
        let businessProcessLevelId = item.businessProcessLevelId;
        this.listofbusinessactivities.push(new models.BusinessProcessActivities({ Id: Id, application: application, lane: lane, recordingType: recordingType, activityType: activityType, activityName: activityName, businessProcessLevelId: businessProcessLevelId }));
      }
    }
    console.log("End final.businessactivitiesDetails");
    console.log(this.listofbusinessactivities);


    //Strategies
    this.businessstrategyDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("03.02.01", "strategy");
    console.log("businessstrategyDetails");
    console.log(this.businessstrategyDetails);
    console.log("businessstrategyDetails length");
    console.log(this.businessstrategyDetails.value.length);

    this.strategyCount=this.businessstrategyDetails.value.length;
    if (this.businessstrategyDetails != undefined && this.businessstrategyDetails.value.length > 0) {


      for (var _i = 0; _i < this.businessstrategyDetails.value.length; _i++) {

        let item = this.businessstrategyDetails.value[_i];
        let Id = item.Id;
        let notes = item.notes;
        let businessProcessLevelId = item.businessProcessLevelId;
        let goalName = item.goalName;
        let metricsName = item.metricsName;
        this.listofbusinessStrategyDetailsData.push(new models.BusinessPorcessMapping({ Id: Id, notes: notes, goalName: goalName, businessProcessLevelId: businessProcessLevelId, metricsName: metricsName }));
      }
    }
    console.log("final.strategy");
    console.log(this.listofbusinessStrategyDetailsData);

    //Assets
    this.businessassestDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R02.04.02.03.03.01", "assest");
    console.log("businessassestDetails");
    console.log(this.businessassestDetails);
    console.log("businessassestDetails length");
    console.log(this.businessassestDetails.value.length);
this.assestsCount=this.businessassestDetails.value.length;

    if (this.businessassestDetails != undefined && this.businessassestDetails.value.length > 0) {
      for (var _i = 0; _i < this.businessassestDetails.value.length; _i++) {
        let item = this.businessassestDetails.value[_i];
        let assetId = item.assetId;
        let assetName = item.assetName;
        let phase = item.phase;
        let description = item.description;
        let businessProcessLevelId = item.businessProcessLevelId;
        let previewSrc = item.previewSrc;
        if (previewSrc!="")
        { this.vdxFileUrlSrc = previewSrc}
        let accelerator = item.accelerator;
        let imageIcon = item.imageIcon;
        this.listofassestDetailsData.push(new models.BusinessProcessAssets({ assetId: assetId, assetName: assetName, phase: phase, description: description, businessProcessLevelId: businessProcessLevelId, previewSrc: previewSrc, accelerator: accelerator,imageIcon:imageIcon }));
      }
    }
    console.log("final.businessassestDetails");
    console.log(this.listofassestDetailsData);

    //Accelerator
    this.businessaccelaratorDetails = this._industryService.GetBusinessprocessdatabyProcessLevel("R01.03.02.01.01.02", "accelarator");
    console.log("businessaccelaratorDetails");
    console.log(this.businessaccelaratorDetails);
    console.log("businessaccelaratorDetails length");
    console.log(this.businessaccelaratorDetails.value.length);
this.accelaratorCount= this.businessaccelaratorDetails.value.length;
    if (this.businessaccelaratorDetails != undefined && this.businessaccelaratorDetails.value.length > 0) {
      for (var _i = 0; _i < this.businessaccelaratorDetails.value.length; _i++) {
        let item = this.businessaccelaratorDetails.value[_i];

        let assetId = item.assetId;
        let assetName = item.assetName;
        let phase = item.phase;
        let description = item.description;
        let businessProcessLevelId = item.businessProcessLevelId;
        let previewSrc = item.previewSrc;
        if (previewSrc!="")
        { this.vdxFileUrlSrc = previewSrc}
        let accelerator = item.accelerator;
        let imageIcon = item.imageIcon;

        this.listofaccelaratorDetailsData.push(new models.BusinessPorcessAccelerator({ assetId: assetId, assetName: assetName, phase: phase, description: description, businessProcessLevelId: businessProcessLevelId, previewSrc: previewSrc, accelerator: accelerator,imageIcon:imageIcon }));
      }

    }
   
    console.log("final.businessaccelaratorDetails");
    console.log(this.listofaccelaratorDetailsData);
    this.tabList.push({ name : 'Preview', count:1});
    this.tabList.push({ name : 'Strategies',count:this.strategyCount});
    this.tabList.push({ name : 'Activities', count:this.activitiesCount});
    this.tabList.push({ name : 'Accelerators', count:this.accelaratorCount});
    this.tabList.push({ name : 'Assets', count:this.assestsCount});      
  }
tabChanged($event: any) {
    this.showTile = $event;
}
}
