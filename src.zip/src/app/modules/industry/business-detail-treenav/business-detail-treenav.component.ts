import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SearchFilterPipe } from '../../../shared/pipes/filter.pipe';
import { IndustryService } from '../../../service/_services/industry.service';
import { Pipe, PipeTransform } from '@angular/core';
import * as models from '../../../service/_models'; 
import {  Searching } from '../../../shared/components/xd-search/xd-search.component';
//import {  Paging } from '../../../shared/components/xd-pager/xd-pager.component';
import {  ViewContainerRef, ComponentFactoryResolver, ViewChild, ComponentRef } from '@angular/core';

@Component({
    selector: 'app-business-detail-treenav',
    templateUrl: './business-detail-treenav.component.html',
    styleUrls: ['./business-detail-treenav.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class BusinessDetailTreenavComponent implements OnInit {
    private listofSearchItems: Array<models.BPSearch>;

    filteredData: any;
    regex: any;
    transformData: any;
    newData: any;
    listData: any[];
    filteredListData: any[];
    test: any;
    test1: any;
    showTile: boolean;
    @Input() data: any[];
    showSearch:boolean;
    showProcess:boolean;
    showNoResultsProcess:boolean;
    showEntire:boolean;
    showIcon:boolean;
    newformat:any[]
    //tree
    constructor(private _industryService: IndustryService) {
        this.listofSearchItems = new Array<models.BPSearch>();


        //this.test="to";
        this.showTile = false;
        this.showSearch=false;
        this.showProcess=false;
        this.showNoResultsProcess=false;
        this.showEntire=false;
        this.showIcon=false;
        this.newformat=[{
            "03 Plan/Market to Customer": {
              "03.02 Merchandise ＆ financial Planning": {
                "03.02.01 Merchandise and Financial Plan Approval": {
                },
                "03.02.02 Category Plan Management": {
                  "03.02.02.01 Category Plan Managements": {
                  }
                },
                "03.02.03 Location Plan Management": {
                  "03.02.03.01 Location plan management": {
                    "R01.03.02.03.01.01 Location plan management": {}
                  }
                },
                "03.02.04 Key Item Plan Management": {
                  "03.02.04.01 Key item plan management": {
                    "R01.03.02.04.01.01 Key item plan management": {}
                  }
                }
              },
              "03.03 Manage Assortment": {
                "03.03.01 Assortment Management": {
                  "03.03.01.01 Assortment management": {
                    "R01.03.03.01.01.01 Assortment management": {}
                  }
                }
              },
              "03.05 Media ＆ Advertising Management": {
                "03.05.02 Advertising Management": {
                  "03.05.02.05 Execute Advertising Plans": {
                    "R01.03.05.02.05.01 Execute Advertising Plans": {},
                    "R01.03.05.02.05.02 Manage distribution of triggered emails": {}
                  }
                },
                "03.05.04 Campaign Management": {
                  "03.05.04.01 Campaign management": {
                    "R01.03.05.04.01.01 Campaign management": {}
                  },
                  "03.05.04.04 Campaign Management Execution": {
                    "R01.03.05.04.04.01 Campaign Management Execution": {},
                    "R01.03.05.04.04.02 Campaign Planning": {}
                  }
                }
              },
              "03.06 Manage Price, Promotions ＆ Offers": {
                "03.06.01 Price Management": {
                  "03.06.01.02 Evaluate define optimize regular promotional pricing": {
                    "R02.03.06.01.02.01 Define and optimize regular, promotional pricing": {}
                  },
                  "03.06.01.06 Integrate and maintain Prices across Channels": {
                    "R01.03.06.01.06.01 Create sales price for stores/customers in Trade Agreements": {},
                    "R01.03.06.01.06.02 Maintain sales price for stores/customers in Trade Agreements": {}
                  },
                  "03.06.01.08 Initiate a discount or price adjustment": {
                    "R01.03.06.01.08.01 Initiate a Discount or price adjustment": {}
                  }
                }
              }
            },
            "06 Retail Data Management": {
              "06.02 Product Information Management": {
                "06.02.01 Item Management": {
                  "06.02.01.01 Create a Product (single and mass update)": {
                    "R03.06.02.01.01.01 Create a Product": {}
                  },
                  "06.02.01.02 Manage Retail Product (single and mass update)": {
                    "R03.06.02.01.02.01 Manage Retail Product": {}
                  },
                  "06.02.01.03 Set up Retail Category Hierarchy": {
                    "R02.06.02.01.03.01 Set up Retail Category Hierarchy": {}
                  }
                },
                "06.02.02 Providing Product Attributes": {
                  "06.02.02.01 Set up product attributes": {
                    "R01.06.02.02.01.01 Set up product attributes": {}
                  },
                  "06.02.02.02 Maintain Product Attributes": {
                    "R01.06.02.02.02.01 Providing Product Attributes": {}
                  }
                },
                "06.02.03 Provisioning Product configuration": {
                  "06.02.03.01 Provisioning Product Configuration": {
                    "R01.06.02.03.01.01 Provisioning Product Configuration": {}
                  }
                },
                "06.02.04 Managing Product Bundling": {
                  "06.02.04.01 Maintain Products Bundling": {
                    "R02.06.02.04.01.01 Maintain Products Bundling": {}
                  }
                },
                "06.02.05 Managing Cross Sell and Up Sell Rules": {
                  "06.02.05.01 Managing Cross Sell and Up Sell Rules": {
                    "R03.06.02.05.01.01 Managing Cross Sell and Up Sell Rules": {}
                  }
                },
                "06.02.06 Product Cross Reference ＆ Replacement": {
                  "06.02.06.01 Product Cross Reference ＆ Replacement": {
                    "R03.06.02.06.01.01 Product Cross Reference ＆ Replacement": {}
                  }
                }
              }
            }
          }];

        this.newData = [
            {
                "LevelName": "Plan/Market to Customer",
                "LevelID": "03",
                "Level2Data": [
                    {
                        "LevelName": "Merchandise ＆ financial Planning",
                        "LevelID": "03.02",
                        "Level3Data": [
                            {
                                "LevelName": "Merchandise and Financial Plan Approval",
                                "LevelID": "03.02.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Merchanise and financial plan",
                                        "LevelID": "03.02.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Merchandise and financial planning",
                                                "LevelID": "R01.03.02.01.01.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Category Plan Management",
                                "LevelID": "03.02.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Category Plan Managements",
                                        "LevelID": "03.02.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Category Plan Management",
                                                "LevelID": "R01.03.02.02.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Location Plan Management",
                                "LevelID": "03.02.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Location plan management",
                                        "LevelID": "03.02.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Location plan management",
                                                "LevelID": "R01.03.02.03.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Key Item Plan Management",
                                "LevelID": "03.02.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Key item plan management",
                                        "LevelID": "03.02.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Key item plan management",
                                                "LevelID": "R01.03.02.04.01.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Assortment",
                        "LevelID": "03.03",
                        "Level3Data": [
                            {
                                "LevelName": "Assortment Management",
                                "LevelID": "03.03.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Assortment management",
                                        "LevelID": "03.03.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Assortment management",
                                                "LevelID": "R01.03.03.01.01.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Media ＆ Advertising Management",
                        "LevelID": "03.05",
                        "Level3Data": [
                            {
                                "LevelName": "Advertising Management",
                                "LevelID": "03.05.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Execute Advertising Plans",
                                        "LevelID": "03.05.02.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Execute Advertising Plans",
                                                "LevelID": "R01.03.05.02.05.01"
                                            },
                                            {
                                                "LevelName": "Manage distribution of triggered emails",
                                                "LevelID": "R01.03.05.02.05.02"
                                            },
                                            {
                                                "LevelName": "Manage distribution of targeted emails",
                                                "LevelID": "R01.03.05.02.05.03"
                                            },
                                            {
                                                "LevelName": "Manage affiliate network",
                                                "LevelID": "R01.03.05.02.05.04"
                                            },
                                            {
                                                "LevelName": "Investigate click fraud",
                                                "LevelID": "R01.03.05.02.05.05"
                                            },
                                            {
                                                "LevelName": "Manage paid (for) search",
                                                "LevelID": "R01.03.05.02.05.06"
                                            },
                                            {
                                                "LevelName": "Define Paid (For) Search campaign",
                                                "LevelID": "R01.03.05.02.05.07"
                                            },
                                            {
                                                "LevelName": "Manage on-site advertising space",
                                                "LevelID": "R01.03.05.02.05.08"
                                            },
                                            {
                                                "LevelName": "Execute viral marketing",
                                                "LevelID": "R01.03.05.02.05.09"
                                            },
                                            {
                                                "LevelName": "Manage Online Media Campaigns",
                                                "LevelID": "R01.03.05.02.05.10"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Campaign Management",
                                "LevelID": "03.05.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Campaign management",
                                        "LevelID": "03.05.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Campaign management",
                                                "LevelID": "R01.03.05.04.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Campaign Management Execution",
                                        "LevelID": "03.05.04.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Campaign Management Execution",
                                                "LevelID": "R01.03.05.04.04.01"
                                            },
                                            {
                                                "LevelName": "Campaign Planning",
                                                "LevelID": "R01.03.05.04.04.02"
                                            },
                                            {
                                                "LevelName": "Campaign Execution",
                                                "LevelID": "R01.03.05.04.04.03"
                                            },
                                            {
                                                "LevelName": "Campaign Broadcasting",
                                                "LevelID": "R01.03.05.04.04.04"
                                            },
                                            {
                                                "LevelName": "Campaign Follow-up",
                                                "LevelID": "R01.03.05.04.04.05"
                                            },
                                            {
                                                "LevelName": "Campaign to Social Media publishing",
                                                "LevelID": "R01.03.05.04.04.07"
                                            },
                                            {
                                                "LevelName": "Manage campaign execution",
                                                "LevelID": "R01.03.05.04.04.08"
                                            },
                                            {
                                                "LevelName": "Campaign to Social Media Set up",
                                                "LevelID": "R03.03.05.04.04.06"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Price, Promotions ＆ Offers",
                        "LevelID": "03.06",
                        "Level3Data": [
                            {
                                "LevelName": "Price Management",
                                "LevelID": "03.06.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Evaluate define optimize regular promotional pricing",
                                        "LevelID": "03.06.01.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Define and optimize regular, promotional pricing",
                                                "LevelID": "R02.03.06.01.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Integrate and maintain Prices across Channels",
                                        "LevelID": "03.06.01.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create sales price for stores/customers in Trade Agreements",
                                                "LevelID": "R01.03.06.01.06.01"
                                            },
                                            {
                                                "LevelName": "Maintain sales price for stores/customers in Trade Agreements",
                                                "LevelID": "R01.03.06.01.06.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Initiate a discount or price adjustment",
                                        "LevelID": "03.06.01.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Initiate a Discount or price adjustment",
                                                "LevelID": "R01.03.06.01.08.01"
                                            },
                                            {
                                                "LevelName": "Maintain a discount or price-adjustment",
                                                "LevelID": "R02.03.06.01.08.02"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "LevelName": "Supply to Customer",
                "LevelID": "04",
                "Level2Data": [
                    {
                        "LevelName": "Manage Supply",
                        "LevelID": "04.01",
                        "Level3Data": [
                            {
                                "LevelName": "Source Products",
                                "LevelID": "04.01.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Source Products",
                                        "LevelID": "04.01.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct selection process",
                                                "LevelID": "R01.04.01.02.01.02"
                                            },
                                            {
                                                "LevelName": "Select vendors",
                                                "LevelID": "R01.04.01.02.01.03"
                                            },
                                            {
                                                "LevelName": "Identify selection factors and screen vendors",
                                                "LevelID": "R02.04.01.02.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Agreement / Contract and Rebate Management",
                                "LevelID": "04.01.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Negotiate and create agreements",
                                        "LevelID": "04.01.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Shape and negotiate trade agreements",
                                                "LevelID": "R01.04.01.03.01.01"
                                            },
                                            {
                                                "LevelName": "Negotiate and create blanket orders",
                                                "LevelID": "R01.04.01.03.01.03"
                                            },
                                            {
                                                "LevelName": "Negotiate and create purchase agreements",
                                                "LevelID": "R02.04.01.03.01.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Implement and manage agreements",
                                        "LevelID": "04.01.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Implement and manage trade agreements",
                                                "LevelID": "R01.04.01.03.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage agreements",
                                        "LevelID": "04.01.03.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage/Update pricing",
                                                "LevelID": "R01.04.01.03.03.06"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Vendor rebate management",
                                        "LevelID": "04.01.03.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Vendor Rebate Parameters",
                                                "LevelID": "R01.04.01.03.04.03"
                                            },
                                            {
                                                "LevelName": "Create Vendor Rebates",
                                                "LevelID": "R02.04.01.03.04.01"
                                            },
                                            {
                                                "LevelName": "Create Vendor Rebate Agreement",
                                                "LevelID": "R02.04.01.03.04.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Customer Rebate Management",
                                        "LevelID": "04.01.03.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up trade allowance",
                                                "LevelID": "R02.04.01.03.05.03"
                                            },
                                            {
                                                "LevelName": "Set up Customer rebate",
                                                "LevelID": "R02.04.01.03.05.04"
                                            },
                                            {
                                                "LevelName": "Create and maintain customer rebate agreement",
                                                "LevelID": "R02.04.01.03.05.05"
                                            },
                                            {
                                                "LevelName": "Create trade allowance agreement",
                                                "LevelID": "R02.04.01.03.05.06"
                                            },
                                            {
                                                "LevelName": "Create and maintain trade allowance",
                                                "LevelID": "R03.04.01.03.05.01"
                                            },
                                            {
                                                "LevelName": "Create and maintain Customer rebate",
                                                "LevelID": "R03.04.01.03.05.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Supplier Management",
                                "LevelID": "04.01.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage vendor data",
                                        "LevelID": "04.01.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Vendor holds",
                                                "LevelID": "R01.04.01.04.01.04"
                                            },
                                            {
                                                "LevelName": "Set up Vendor and Procurement Related data",
                                                "LevelID": "R02.04.01.04.01.01"
                                            },
                                            {
                                                "LevelName": "Create and maintain vendor master information",
                                                "LevelID": "R02.04.01.04.01.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Procurement Quality",
                                        "LevelID": "04.01.04.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Procurement Quality",
                                                "LevelID": "R01.04.01.04.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Evaluate and Improve vendor performance",
                                        "LevelID": "04.01.04.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Assess and review relationship with vendors",
                                                "LevelID": "R01.04.01.04.03.01"
                                            },
                                            {
                                                "LevelName": "Gather statistics from order history",
                                                "LevelID": "R01.04.01.04.03.02"
                                            },
                                            {
                                                "LevelName": "Gather quality and delivery accuracy statistics",
                                                "LevelID": "R01.04.01.04.03.03"
                                            },
                                            {
                                                "LevelName": "Set up vendor ratings",
                                                "LevelID": "R01.04.01.04.03.05"
                                            },
                                            {
                                                "LevelName": "Set up and distribute a questionnaire",
                                                "LevelID": "R03.04.01.04.03.04"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Evaluate and Improve product performance",
                                        "LevelID": "04.01.04.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Quality Control",
                                                "LevelID": "R01.04.01.04.04.05"
                                            },
                                            {
                                                "LevelName": "Evaluate and Improve Product Quality",
                                                "LevelID": "R02.04.01.04.04.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Inventory",
                        "LevelID": "04.02",
                        "Level3Data": [
                            {
                                "LevelName": "Inventory Planning ＆ Forecasting",
                                "LevelID": "04.02.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Analyse products based on demand characteristics from various channels",
                                        "LevelID": "04.02.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Apply demand characteristics to historical data",
                                                "LevelID": "R01.04.02.01.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Allocation Management",
                                "LevelID": "04.02.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Review allocation targets and constraints",
                                        "LevelID": "04.02.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Review allocation targets and constraints",
                                                "LevelID": "R01.04.02.02.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Replenishment Management",
                                "LevelID": "04.02.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Review replenishment targets and constraints from all channels",
                                        "LevelID": "04.02.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Review replenishment targets and constraints from all channels",
                                                "LevelID": "R01.04.02.03.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Establish replenishment parameters by store/delivery channel",
                                        "LevelID": "04.02.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Establish replenishment parameters by store/delivery channel",
                                                "LevelID": "R01.04.02.03.02.01"
                                            },
                                            {
                                                "LevelName": "Refine replenishment parameters based latest baseline / pre season forecast",
                                                "LevelID": "R01.04.02.03.02.02"
                                            },
                                            {
                                                "LevelName": "Execute master scheduling process",
                                                "LevelID": "R01.04.02.03.02.03"
                                            },
                                            {
                                                "LevelName": "Maintaining planned orders",
                                                "LevelID": "R01.04.02.03.02.04"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Advanced Replenishment AVA",
                                        "LevelID": "04.02.03.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Setup Advanced Store Replenishment",
                                                "LevelID": "R02.04.02.03.03.01"
                                            },
                                            {
                                                "LevelName": "Manage Seasonal Co-efficient",
                                                "LevelID": "R02.04.02.03.03.02"
                                            },
                                            {
                                                "LevelName": "Manage Special Sales Co-efficient",
                                                "LevelID": "R02.04.02.03.03.03"
                                            },
                                            {
                                                "LevelName": "Manage Weekly Co-efficients",
                                                "LevelID": "R02.04.02.03.03.04"
                                            },
                                            {
                                                "LevelName": "Process Corrected Average Sales",
                                                "LevelID": "R02.04.02.03.03.05"
                                            },
                                            {
                                                "LevelName": "Manage Safety stock for Advanced Replenishment",
                                                "LevelID": "R02.04.02.03.03.06"
                                            },
                                            {
                                                "LevelName": "Manage Advanced Replenishment Rules",
                                                "LevelID": "R02.04.02.03.03.07"
                                            },
                                            {
                                                "LevelName": "Manage advanced replenishment order",
                                                "LevelID": "R02.04.02.03.03.08"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Purchase Order Management",
                                "LevelID": "04.02.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Create and Maintain Purchase Order",
                                        "LevelID": "04.02.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Purchase Order Management (Retail)-Advanced Replenishment",
                                                "LevelID": "R01.04.02.04.01.01"
                                            },
                                            {
                                                "LevelName": "Apply Charges to Purchase Orders",
                                                "LevelID": "R01.04.02.04.01.02"
                                            },
                                            {
                                                "LevelName": "Create and maintain Delivery Schedule",
                                                "LevelID": "R01.04.02.04.01.03"
                                            },
                                            {
                                                "LevelName": "Release orders against purchase agreements",
                                                "LevelID": "R01.04.02.04.01.09"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Close purchase order",
                                        "LevelID": "04.02.04.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Complete ＆ Close Purchase Order",
                                                "LevelID": "R01.04.02.04.02.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Invoice Verification",
                                "LevelID": "04.02.06",
                                "Level4Data": [
                                    {
                                        "LevelName": "Perform Invoice Matching",
                                        "LevelID": "04.02.06.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Invoice Matching",
                                                "LevelID": "R02.04.02.06.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Invoices",
                                        "LevelID": "04.02.06.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Purchase Order Invoices via Purchase Order Directly",
                                                "LevelID": "R01.04.02.06.02.01"
                                            },
                                            {
                                                "LevelName": "Process Purchase Order Invoices via Invoice Register",
                                                "LevelID": "R01.04.02.06.02.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Tracking and Traceability",
                                "LevelID": "04.02.07",
                                "Level4Data": [
                                    {
                                        "LevelName": "Batch Number Control",
                                        "LevelID": "04.02.07.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Batch Numbers",
                                                "LevelID": "R02.04.02.07.01.01"
                                            },
                                            {
                                                "LevelName": "Manage Batch Numbers",
                                                "LevelID": "R02.04.02.07.01.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Serial Number Control",
                                        "LevelID": "04.02.07.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Serial Numbers",
                                                "LevelID": "R02.04.02.07.02.01"
                                            },
                                            {
                                                "LevelName": "Manage Serial Numbers",
                                                "LevelID": "R02.04.02.07.02.02"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Transportation",
                        "LevelID": "04.03",
                        "Level3Data": [
                            {
                                "LevelName": "Shipment Management",
                                "LevelID": "04.03.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Inbound/ Outbound Shipments",
                                        "LevelID": "04.03.03.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Transportation Master Data",
                                                "LevelID": "R02.04.03.03.04.01"
                                            },
                                            {
                                                "LevelName": "Transportation Network Setup",
                                                "LevelID": "R02.04.03.03.04.02"
                                            },
                                            {
                                                "LevelName": "Carrier and Rating Setup",
                                                "LevelID": "R02.04.03.03.04.03"
                                            },
                                            {
                                                "LevelName": "Appointment Scheduling",
                                                "LevelID": "R02.04.03.03.04.04"
                                            },
                                            {
                                                "LevelName": "Operational Planning",
                                                "LevelID": "R02.04.03.03.04.05"
                                            },
                                            {
                                                "LevelName": "Appointment Execution",
                                                "LevelID": "R02.04.03.03.04.06"
                                            },
                                            {
                                                "LevelName": "Freight Reconciliation",
                                                "LevelID": "R02.04.03.03.04.07"
                                            },
                                            {
                                                "LevelName": "Transport execution",
                                                "LevelID": "R02.04.03.03.04.08"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage DC/Warehouse",
                        "LevelID": "04.05",
                        "Level3Data": [
                            {
                                "LevelName": "DC/Warehouse Management",
                                "LevelID": "04.05.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Distribution Centre",
                                        "LevelID": "04.05.01.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Warehousing Related Data",
                                                "LevelID": "R02.04.05.01.04.01"
                                            },
                                            {
                                                "LevelName": "Pick, Pack and Ship Goods",
                                                "LevelID": "R02.04.05.01.04.02"
                                            },
                                            {
                                                "LevelName": "Pack",
                                                "LevelID": "R02.04.05.01.04.04"
                                            },
                                            {
                                                "LevelName": "Stage/Ship",
                                                "LevelID": "R02.04.05.01.04.05"
                                            },
                                            {
                                                "LevelName": "Process internal replenishment",
                                                "LevelID": "R02.04.05.01.04.06"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "DC Receipt/Return Management",
                                "LevelID": "04.05.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Receive stock",
                                        "LevelID": "04.05.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Receive and Put Away Goods",
                                                "LevelID": "R02.04.05.02.01.04"
                                            },
                                            {
                                                "LevelName": "Process Inventory Receipt",
                                                "LevelID": "R02.04.05.02.01.05"
                                            },
                                            {
                                                "LevelName": "Receive Goods and Materials",
                                                "LevelID": "R02.04.05.02.01.06"
                                            },
                                            {
                                                "LevelName": "DC/Warehouse Receipt Management",
                                                "LevelID": "R03.04.05.02.01.01"
                                            },
                                            {
                                                "LevelName": "Store receive (From DC or Vendor)",
                                                "LevelID": "R03.04.05.02.01.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Returns",
                                        "LevelID": "04.05.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Retail Customer Return - (Customer to Warehouse)",
                                                "LevelID": "R01.04.05.02.02.02"
                                            },
                                            {
                                                "LevelName": "DC/Warehouse Return Management",
                                                "LevelID": "R02.04.05.02.02.01"
                                            },
                                            {
                                                "LevelName": "Process Customer Returns (Customer to Warehouse)",
                                                "LevelID": "R02.04.05.02.02.04"
                                            },
                                            {
                                                "LevelName": "Manage Return to Supplier",
                                                "LevelID": "R02.04.05.02.02.05"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Packaging and Assembly",
                                "LevelID": "04.05.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Packaging and Assembly",
                                        "LevelID": "04.05.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Packaging and Assembly",
                                                "LevelID": "R02.04.05.03.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Inventory Control Management/DC",
                                "LevelID": "04.05.06",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Non Owned/ Virtual Inventory",
                                        "LevelID": "04.05.06.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Non Owned Inventory",
                                                "LevelID": "R01.04.05.06.01.01"
                                            },
                                            {
                                                "LevelName": "Managed Virtual Inventory (Promised by Vendor/supplier)",
                                                "LevelID": "R01.04.05.06.01.02"
                                            },
                                            {
                                                "LevelName": "Manage Non Owned Inventory (Consignment)",
                                                "LevelID": "R01.04.05.06.01.03"
                                            },
                                            {
                                                "LevelName": "Consume Materials from Vendor Consignment Warehouse (AVA Asset)",
                                                "LevelID": "R01.04.05.06.01.04"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Inventory Levels with inputs from all channels",
                                        "LevelID": "04.05.06.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Inventory Levels with inputs from all channels",
                                                "LevelID": "R01.04.05.06.02.01"
                                            },
                                            {
                                                "LevelName": "Manage Overs/Under Inventory Levels",
                                                "LevelID": "R02.04.05.06.02.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Plan and execute inventory counts",
                                        "LevelID": "04.05.06.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Inventory Status",
                                                "LevelID": "R02.04.05.06.03.02"
                                            },
                                            {
                                                "LevelName": "Store cycle count",
                                                "LevelID": "R03.04.05.06.03.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Inventory Storage",
                                        "LevelID": "04.05.06.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Discontinued Inventory",
                                                "LevelID": "R01.04.05.06.04.04"
                                            },
                                            {
                                                "LevelName": "Manage Inventory Storage",
                                                "LevelID": "R02.04.05.06.04.01"
                                            },
                                            {
                                                "LevelName": "Define Warehouse Organizational Structure (WMS1)",
                                                "LevelID": "R02.04.05.06.04.05"
                                            },
                                            {
                                                "LevelName": "Define Warehouse Organizational Structure",
                                                "LevelID": "R02.04.05.06.04.06"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "LevelName": "Sell to Customer",
                "LevelID": "05",
                "Level2Data": [
                    {
                        "LevelName": "Manage Commercial Operations",
                        "LevelID": "05.01",
                        "Level3Data": [
                            {
                                "LevelName": "Sales Management",
                                "LevelID": "05.01.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Review, refine and/or adjust financial plan/goal (where necessary)",
                                        "LevelID": "05.01.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Review, refine and/or adjust �financial plan/goal",
                                                "LevelID": "R01.05.01.01.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Re-evaluate and execute financial plan/goals (where necessary)",
                                        "LevelID": "05.01.01.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Re-evaluate and execute Financial Plan/Goals",
                                                "LevelID": "R01.05.01.01.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor trend performance to financial plan/goal/peers",
                                        "LevelID": "05.01.01.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor trend performance to financial plan/goal/peers",
                                                "LevelID": "R01.05.01.01.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct competitive shops",
                                        "LevelID": "05.01.01.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct competitive shops",
                                                "LevelID": "R01.05.01.01.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Develop and execute action plan to impact results (where necessary)",
                                        "LevelID": "05.01.01.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Develop and execute action plan to impact results",
                                                "LevelID": "R01.05.01.01.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Sales Management - Wholesale",
                                "LevelID": "05.01.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Identify reps, hierarchy, territory and/or product structure",
                                        "LevelID": "05.01.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Identify reps, hierarchy, territory and/or product structure",
                                                "LevelID": "R01.05.01.02.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage client/account financial plans/goals",
                                        "LevelID": "05.01.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage client/account financial plans/goals",
                                                "LevelID": "R01.05.01.02.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct Sales Calls/Meetings",
                                        "LevelID": "05.01.02.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct Sales Calls/Meetings",
                                                "LevelID": "R01.05.01.02.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Select Target Accounts/Business Development",
                                        "LevelID": "05.01.02.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Select Target Accounts/Business Development",
                                                "LevelID": "R01.05.01.02.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain Account Relations",
                                        "LevelID": "05.01.02.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain Account Relations",
                                                "LevelID": "R01.05.01.02.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Partner and Alliance Management (Tactical)",
                                "LevelID": "05.01.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Identify partners/alliances to fit corporate strategy",
                                        "LevelID": "05.01.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Identify partners/alliances to fit corporate strategy",
                                                "LevelID": "R01.05.01.03.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Acquire best alliance partners",
                                        "LevelID": "05.01.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Acquire best alliance partners",
                                                "LevelID": "R01.05.01.03.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Review and optimize portfolio",
                                        "LevelID": "05.01.03.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Review and optimize portfolio",
                                                "LevelID": "R01.05.01.03.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maximize day-to-day performance",
                                        "LevelID": "05.01.03.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maximize day-to-day performance",
                                                "LevelID": "R01.05.01.03.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Capitalize on products/services created",
                                        "LevelID": "05.01.03.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Capitalize on products/services created",
                                                "LevelID": "R01.05.01.03.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Business Performance Management / In Season Management",
                                "LevelID": "05.01.05",
                                "Level4Data": [
                                    {
                                        "LevelName": "Monitor open to buy plan",
                                        "LevelID": "05.01.05.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor open to buy plan",
                                                "LevelID": "R01.05.01.05.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor category plan",
                                        "LevelID": "05.01.05.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor category plan",
                                                "LevelID": "R03.05.01.05.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor supplier plan",
                                        "LevelID": "05.01.05.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor supplier plan",
                                                "LevelID": "R01.05.01.05.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor location plan",
                                        "LevelID": "05.01.05.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor location plan",
                                                "LevelID": "R01.05.01.05.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor key item plan",
                                        "LevelID": "05.01.05.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor key item plan",
                                                "LevelID": "R03.05.01.05.05.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "End of season plan management",
                                        "LevelID": "05.01.05.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "End of season plan management",
                                                "LevelID": "R01.05.01.05.06.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Sales Partner Management",
                        "LevelID": "05.02",
                        "Level3Data": [
                            {
                                "LevelName": "Sales Management - Direct/Agency Selling",
                                "LevelID": "05.02.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Determine number of distributors needed",
                                        "LevelID": "05.02.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Determine business opportunity by geography",
                                                "LevelID": "R01.05.02.01.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Recruit distributors",
                                        "LevelID": "05.02.01.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Recruit distributors",
                                                "LevelID": "R01.05.02.01.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Train distributors",
                                        "LevelID": "05.02.01.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Train distributors",
                                                "LevelID": "R01.05.02.01.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct sales calls",
                                        "LevelID": "05.02.01.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct sales calls",
                                                "LevelID": "R01.05.02.01.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain customer relations",
                                        "LevelID": "05.02.01.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain customer relations",
                                                "LevelID": "R01.05.02.01.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Partner ＆ alliance management",
                                "LevelID": "05.02.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Determine Partner ＆ alliance opportunity by geography",
                                        "LevelID": "05.02.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Determine Partner ＆ alliance opportunity by geography",
                                                "LevelID": "R01.05.02.02.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Recruit partners",
                                        "LevelID": "05.02.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Recruit partners",
                                                "LevelID": "R01.05.02.02.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Train partners",
                                        "LevelID": "05.02.02.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Train partners",
                                                "LevelID": "R01.05.02.02.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct partner calls",
                                        "LevelID": "05.02.02.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct partner calls",
                                                "LevelID": "R01.05.02.02.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain partner relations",
                                        "LevelID": "05.02.02.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain partner relations",
                                                "LevelID": "R01.05.02.02.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Franchise management",
                                "LevelID": "05.02.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Determine franchisee by geography",
                                        "LevelID": "05.02.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Determine franchisee by geography",
                                                "LevelID": "R01.05.02.03.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Recruit franchisees",
                                        "LevelID": "05.02.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Recruit franchisees",
                                                "LevelID": "R01.05.02.03.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Train franchisees",
                                        "LevelID": "05.02.03.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Train franchisees",
                                                "LevelID": "R01.05.02.03.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct franchisee calls",
                                        "LevelID": "05.02.03.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct franchisee calls",
                                                "LevelID": "R01.05.02.03.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain franchisee relations",
                                        "LevelID": "05.02.03.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain franchisee relations",
                                                "LevelID": "R01.05.02.03.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Affiliate management",
                                "LevelID": "05.02.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Determine affiliates by geography",
                                        "LevelID": "05.02.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Determine affiliates by geography",
                                                "LevelID": "R01.05.02.04.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Recruit affiliates",
                                        "LevelID": "05.02.04.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Recruit affiliates",
                                                "LevelID": "R01.05.02.04.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Train affiliates",
                                        "LevelID": "05.02.04.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Train affiliates",
                                                "LevelID": "R01.05.02.04.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct affiliate calls",
                                        "LevelID": "05.02.04.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct affiliate calls",
                                                "LevelID": "R01.05.02.04.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain customer affiliates",
                                        "LevelID": "05.02.04.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain customer affiliates",
                                                "LevelID": "R01.05.02.04.05.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Customer Experience",
                        "LevelID": "05.03",
                        "Level3Data": [
                            {
                                "LevelName": "Customer Services Management",
                                "LevelID": "05.03.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Align selling activities and tools with customer expectations",
                                        "LevelID": "05.03.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Align selling activities and tools with customer expectations",
                                                "LevelID": "R01.05.03.01.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct sales force training",
                                        "LevelID": "05.03.01.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct sales force training",
                                                "LevelID": "R01.05.03.01.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Perform Selling Activities",
                                        "LevelID": "05.03.01.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Perform Selling activities",
                                                "LevelID": "R01.05.03.01.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage customer inquiries/issue resolution",
                                        "LevelID": "05.03.01.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage customer inquiries/issue resolution",
                                                "LevelID": "R01.05.03.01.04.01"
                                            },
                                            {
                                                "LevelName": "Set up pre-requisite for case management",
                                                "LevelID": "R01.05.03.01.04.02"
                                            },
                                            {
                                                "LevelName": "Manage customer cases",
                                                "LevelID": "R02.05.03.01.04.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Monitor customer satisfaction and quality of service",
                                        "LevelID": "05.03.01.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Monitor customer satisfaction and quality of service",
                                                "LevelID": "R01.05.03.01.05.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage ongoing customer contact (i.e.: clienteling)",
                                        "LevelID": "05.03.01.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage ongoing customer contact (i.e.: clienteling)",
                                                "LevelID": "R01.05.03.01.06.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage special services programs: Gift Registry",
                                        "LevelID": "05.03.01.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage special services programs: Gift Registry",
                                                "LevelID": "R01.05.03.01.07.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage special services program (Gift Wrap, Tailoring, Valet Parking, and Personal Shopping)",
                                        "LevelID": "05.03.01.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage special services program (Gift Wrap, Tailoring, Valet Parking, and Personal Shopping)",
                                                "LevelID": "R01.05.03.01.08.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain customer contacts/profiles",
                                        "LevelID": "05.03.01.09",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain customer contacts/profiles",
                                                "LevelID": "R01.05.03.01.09.01"
                                            },
                                            {
                                                "LevelName": "Maintain Relationship profile and history",
                                                "LevelID": "R01.05.03.01.09.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Customer Order Management",
                                "LevelID": "05.03.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Create and Maintain Sales Order",
                                        "LevelID": "05.03.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create and update Sales Order",
                                                "LevelID": "R02.05.03.02.01.01"
                                            },
                                            {
                                                "LevelName": "Process Direct Shipment Sales Order",
                                                "LevelID": "R02.05.03.02.01.02"
                                            },
                                            {
                                                "LevelName": "Apply coupon to sales order",
                                                "LevelID": "R02.05.03.02.01.03"
                                            },
                                            {
                                                "LevelName": "Process Sales Order hold",
                                                "LevelID": "R02.05.03.02.01.04"
                                            },
                                            {
                                                "LevelName": "Setup Continuity Programme",
                                                "LevelID": "R02.05.03.02.01.05"
                                            },
                                            {
                                                "LevelName": "Create and Maintain Call Center Sales Order",
                                                "LevelID": "R02.05.03.02.01.06"
                                            },
                                            {
                                                "LevelName": "Process Continuity orders",
                                                "LevelID": "R02.05.03.02.01.07"
                                            },
                                            {
                                                "LevelName": "Perform Sales order Cancellation",
                                                "LevelID": "R02.05.03.02.01.08"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Return Management",
                                        "LevelID": "05.03.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Customer Returns",
                                                "LevelID": "R02.05.03.02.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Process Customer Invoices",
                                        "LevelID": "05.03.02.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Send Invoice/Credit Note per Preferred Method",
                                                "LevelID": "R01.05.03.02.03.02"
                                            },
                                            {
                                                "LevelName": "Process Customer Invoices",
                                                "LevelID": "R02.05.03.02.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Apply Charges to Sales Orders",
                                        "LevelID": "05.03.02.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Apply Charges to Sales Orders",
                                                "LevelID": "R02.05.03.02.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Create and Manage Sales Quotation",
                                        "LevelID": "05.03.02.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create and Manage Sales Quotation",
                                                "LevelID": "R01.05.03.02.05.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Process Picking",
                                        "LevelID": "05.03.02.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Picking",
                                                "LevelID": "R02.05.03.02.06.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Recording Goods Receipt for Direct Shipments",
                                        "LevelID": "05.03.02.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Recording Goods Receipt for Direct Shipment",
                                                "LevelID": "R02.05.03.02.07.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage customer contracts",
                                        "LevelID": "05.03.02.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage customer contracts",
                                                "LevelID": "R01.05.03.02.08.01"
                                            },
                                            {
                                                "LevelName": "Create and Maintain Customer Trade Agreements",
                                                "LevelID": "R01.05.03.02.08.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Process Payment",
                                        "LevelID": "05.03.02.09",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process installment payment",
                                                "LevelID": "R02.05.03.02.09.01"
                                            },
                                            {
                                                "LevelName": "Process Call Center Customer payment",
                                                "LevelID": "R02.05.03.02.09.02"
                                            },
                                            {
                                                "LevelName": "Process Check and Credit Card Refund",
                                                "LevelID": "R02.05.03.02.09.03"
                                            },
                                            {
                                                "LevelName": "Handle Payment Issue",
                                                "LevelID": "R02.05.03.02.09.04"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Call Center Coupon",
                                        "LevelID": "05.03.02.10",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create and maintain Call Center Coupon",
                                                "LevelID": "R02.05.03.02.10.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Customer",
                                        "LevelID": "05.03.02.11",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create and manage call center customer",
                                                "LevelID": "R02.05.03.02.11.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Loyalty Management",
                                "LevelID": "05.03.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Management of Members",
                                        "LevelID": "05.03.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Management of Members",
                                                "LevelID": "R01.05.03.03.01.01"
                                            },
                                            {
                                                "LevelName": "Loyalty Scheme Management",
                                                "LevelID": "R01.05.03.03.01.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Customer Analytics and Offer",
                                        "LevelID": "05.03.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Customer Analytics and Offer",
                                                "LevelID": "R01.05.03.03.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Accountancy and Audit",
                                        "LevelID": "05.03.03.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Accountancy and Audit",
                                                "LevelID": "R01.05.03.03.04.01"
                                            },
                                            {
                                                "LevelName": "Handle Loyalty Points",
                                                "LevelID": "R01.05.03.03.04.02"
                                            },
                                            {
                                                "LevelName": "Manage Accounting of Loyalty points",
                                                "LevelID": "R01.05.03.03.04.03"
                                            },
                                            {
                                                "LevelName": "Manage Provision",
                                                "LevelID": "R01.05.03.03.04.04"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Integrated Channel Management",
                                "LevelID": "05.03.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Call center Configuration",
                                        "LevelID": "05.03.04.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Setup Call Center",
                                                "LevelID": "R02.05.03.04.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Online Channel Configuration",
                                        "LevelID": "05.03.04.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Setup Online Channel",
                                                "LevelID": "R03.05.03.04.03.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Call Center Analysis and Inquires",
                                "LevelID": "05.03.09",
                                "Level4Data": [
                                    {
                                        "LevelName": "Call Center Analysis and Inquires",
                                        "LevelID": "05.03.09.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Call Center Analysis and Inquiries",
                                                "LevelID": "R02.05.03.09.01.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Physical Operations",
                        "LevelID": "05.04",
                        "Level3Data": [
                            {
                                "LevelName": "Pricing, Ticketing/Labeling and Signage",
                                "LevelID": "05.04.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Print and affix ticket/label (If not Electronic)",
                                        "LevelID": "05.04.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Product labeling in stores",
                                                "LevelID": "R01.05.04.02.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Print or receive signs",
                                        "LevelID": "05.04.02.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Print shelf labels",
                                                "LevelID": "R01.05.04.02.04.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Loss Prevention",
                                "LevelID": "05.04.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Ongoing monitoring/loss detection",
                                        "LevelID": "05.04.03.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Setup Fraud alerts",
                                                "LevelID": "R02.05.04.03.03.04"
                                            },
                                            {
                                                "LevelName": "Manage call center Fraud",
                                                "LevelID": "R02.05.04.03.03.05"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Back Office Management",
                                "LevelID": "05.04.05",
                                "Level4Data": [
                                    {
                                        "LevelName": "Start of the Day Procedures",
                                        "LevelID": "05.04.05.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Start of the Day Procedures",
                                                "LevelID": "R03.05.04.05.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "End of the Day Procedures",
                                        "LevelID": "05.04.05.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "End of the day Procedure",
                                                "LevelID": "R01.05.04.05.02.01"
                                            },
                                            {
                                                "LevelName": "Perform Shift Closing on MPOS",
                                                "LevelID": "R02.05.04.05.02.05"
                                            },
                                            {
                                                "LevelName": "Perform Inventory counting",
                                                "LevelID": "R03.05.04.05.02.03"
                                            },
                                            {
                                                "LevelName": "Maintain End of Day/Shift Tender Closing",
                                                "LevelID": "R03.05.04.05.02.04"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Cash Management",
                                        "LevelID": "05.04.05.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Cash Management on MPOS",
                                                "LevelID": "R02.05.04.05.03.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Provide change",
                                        "LevelID": "05.04.05.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Provide change on MPOS",
                                                "LevelID": "R02.05.04.05.04.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct End of the Day Sales Audit",
                                        "LevelID": "05.04.05.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct End of the Day Sales Audit",
                                                "LevelID": "R01.05.04.05.05.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Conduct periodic audits",
                                        "LevelID": "05.04.05.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Conduct periodic audits",
                                                "LevelID": "R01.05.04.05.06.01"
                                            },
                                            {
                                                "LevelName": "Conduct Periodic Inventory Audit",
                                                "LevelID": "R01.05.04.05.06.02"
                                            },
                                            {
                                                "LevelName": "Conduct Periodic Tender Audit",
                                                "LevelID": "R03.05.04.05.06.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Point of Sales Export Process",
                                        "LevelID": "05.04.05.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Point of Sales Export Process",
                                                "LevelID": "R01.05.04.05.07.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Point of Sales Import Process",
                                        "LevelID": "05.04.05.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Point of Sales Import Process",
                                                "LevelID": "R01.05.04.05.08.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Logging on and Off (Sell) process",
                                        "LevelID": "05.04.05.09",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage POS operation and Permission",
                                                "LevelID": "R02.05.04.05.09.02"
                                            },
                                            {
                                                "LevelName": "Logging on and Off (Sell) process on MPOS",
                                                "LevelID": "R02.05.04.05.09.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "POS Configuration",
                                        "LevelID": "05.04.05.10",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Attributes for Retail Channel",
                                                "LevelID": "R02.05.04.05.10.03"
                                            },
                                            {
                                                "LevelName": "Manage Register or Terminal for Retail Channel",
                                                "LevelID": "R02.05.04.05.10.04"
                                            },
                                            {
                                                "LevelName": "Setup Worker in Retail Channel",
                                                "LevelID": "R02.05.04.05.10.05"
                                            },
                                            {
                                                "LevelName": "POS Configuration",
                                                "LevelID": "R03.05.04.05.10.01"
                                            },
                                            {
                                                "LevelName": "Setup Retail Channel Prerequisites",
                                                "LevelID": "R03.05.04.05.10.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Catalog Management",
                                        "LevelID": "05.04.05.11",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Catalog",
                                                "LevelID": "R01.05.04.05.11.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Inventory Control Management",
                                "LevelID": "05.04.06",
                                "Level4Data": [
                                    {
                                        "LevelName": "Perform cycle counts",
                                        "LevelID": "05.04.06.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Plan for Cycle count",
                                                "LevelID": "R01.05.04.06.02.02"
                                            },
                                            {
                                                "LevelName": "Process Inventory and Cycle Count",
                                                "LevelID": "R02.05.04.06.02.03"
                                            },
                                            {
                                                "LevelName": "Perform cycle counts",
                                                "LevelID": "R03.05.04.06.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Perform Inventory adjustments based upon guidelines",
                                        "LevelID": "05.04.06.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Inventory Adjustments",
                                                "LevelID": "R02.05.04.06.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Identify and process mark out of stock/salvage merchandise",
                                        "LevelID": "05.04.06.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Perform mark out of stock/salvage",
                                                "LevelID": "R03.05.04.06.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage consignment inventory",
                                        "LevelID": "05.04.06.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage consignment inventory (AVA Asset)",
                                                "LevelID": "R01.05.04.06.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Manage Store Sales",
                                "LevelID": "05.04.07",
                                "Level4Data": [
                                    {
                                        "LevelName": "Customer Management",
                                        "LevelID": "05.04.07.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain Customers at the POS",
                                                "LevelID": "R01.05.04.07.01.01"
                                            },
                                            {
                                                "LevelName": "Create customer at MPOS",
                                                "LevelID": "R02.05.04.07.01.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Tender Management",
                                        "LevelID": "05.04.07.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Tender Management",
                                                "LevelID": "R01.05.04.07.02.01"
                                            },
                                            {
                                                "LevelName": "Coupons Management",
                                                "LevelID": "R01.05.04.07.02.04"
                                            },
                                            {
                                                "LevelName": "Store Credit Management on MPOS",
                                                "LevelID": "R02.05.04.07.02.05"
                                            },
                                            {
                                                "LevelName": "Gift Cards Management",
                                                "LevelID": "R03.05.04.07.02.02"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Perform Daily sales operation",
                                        "LevelID": "05.04.07.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Update Customer Information",
                                                "LevelID": "R01.05.04.07.03.02"
                                            },
                                            {
                                                "LevelName": "Processing Sales on MPOS",
                                                "LevelID": "R02.05.04.07.03.12"
                                            },
                                            {
                                                "LevelName": "Payment Processing on MPOS",
                                                "LevelID": "R02.05.04.07.03.13"
                                            },
                                            {
                                                "LevelName": "Suspend/Recall Sale Transaction on MPOS",
                                                "LevelID": "R02.05.04.07.03.14"
                                            },
                                            {
                                                "LevelName": "Cancel Sales on MPOS",
                                                "LevelID": "R02.05.04.07.03.15"
                                            },
                                            {
                                                "LevelName": "Process Return/Replace on MPOS",
                                                "LevelID": "R02.05.04.07.03.16"
                                            },
                                            {
                                                "LevelName": "Order Pickup on MPOS",
                                                "LevelID": "R02.05.04.07.03.17"
                                            },
                                            {
                                                "LevelName": "Deposit Management in MPOS",
                                                "LevelID": "R02.05.04.07.03.18"
                                            },
                                            {
                                                "LevelName": "Add/Edit Line Items on MPOS",
                                                "LevelID": "R02.05.04.07.03.19"
                                            },
                                            {
                                                "LevelName": "Add/Edit Sales transaction on MPOS",
                                                "LevelID": "R02.05.04.07.03.20"
                                            },
                                            {
                                                "LevelName": "Update customer information on MPOS",
                                                "LevelID": "R02.05.04.07.03.21"
                                            },
                                            {
                                                "LevelName": "Issue Loyalty card on MPOS",
                                                "LevelID": "R02.05.04.07.03.22"
                                            },
                                            {
                                                "LevelName": "Search/Filter products on MPOS",
                                                "LevelID": "R02.05.04.07.03.23"
                                            },
                                            {
                                                "LevelName": "Perform Product Comparison on MPOS",
                                                "LevelID": "R02.05.04.07.03.24"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "POS-Inquires",
                                        "LevelID": "05.04.07.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "MPOS-Inquiries",
                                                "LevelID": "R02.05.04.07.04.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Backroom Management",
                                "LevelID": "05.04.08",
                                "Level4Data": [
                                    {
                                        "LevelName": "Organize backroom",
                                        "LevelID": "05.04.08.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Organize Backroom",
                                                "LevelID": "R01.05.04.08.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Support selling floor replenishment",
                                        "LevelID": "05.04.08.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Support selling floor replenishment",
                                                "LevelID": "R01.05.04.08.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Back-stock",
                                        "LevelID": "05.04.08.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Back-stock",
                                                "LevelID": "R01.05.04.08.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage secured merchandise area",
                                        "LevelID": "05.04.08.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Transfer Journal",
                                                "LevelID": "R01.05.04.08.04.02"
                                            },
                                            {
                                                "LevelName": "Manage secured merchandise area",
                                                "LevelID": "R02.05.04.08.04.01"
                                            },
                                            {
                                                "LevelName": "Transfer of Goods Between Locations within a Warehouse",
                                                "LevelID": "R02.05.04.08.04.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Rework merchandise area",
                                        "LevelID": "05.04.08.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Rework merchandise area",
                                                "LevelID": "R01.05.04.08.05.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage In-Store Pick-Up/Holds area",
                                        "LevelID": "05.04.08.06",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage In-Store Pick-Up/Holds area",
                                                "LevelID": "R01.05.04.08.06.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Return to Vendor and Mark Out of Stock/Salvage area",
                                        "LevelID": "05.04.08.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Return to Vendor and Mark Out of Stock/Salvage area",
                                                "LevelID": "R02.05.04.08.07.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain housekeeping/safety standards",
                                        "LevelID": "05.04.08.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain housekeeping/safety standards",
                                                "LevelID": "R01.05.04.08.08.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Labor Management",
                                "LevelID": "05.04.13",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Time Keeping",
                                        "LevelID": "05.04.13.08",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up time registration for channel",
                                                "LevelID": "R02.05.04.13.08.07"
                                            },
                                            {
                                                "LevelName": "Perform time registration on channel - MPOS",
                                                "LevelID": "R02.05.04.13.08.08"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Manage Inter Channel Fulfillment and Returns",
                                "LevelID": "05.04.16",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Inter Channel Fulfillment and Returns",
                                        "LevelID": "05.04.16.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Inter Channel Fulfillment and Returns",
                                                "LevelID": "R01.05.04.16.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Fulfillment of Order from Store",
                                        "LevelID": "05.04.16.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Executability Check and Allocation",
                                                "LevelID": "R02.05.04.16.02.04"
                                            },
                                            {
                                                "LevelName": "Manage Transfer Orders between warehouses - WMS II",
                                                "LevelID": "R02.05.04.16.02.05"
                                            },
                                            {
                                                "LevelName": "Finalize details of sales order",
                                                "LevelID": "R02.05.04.16.02.06"
                                            },
                                            {
                                                "LevelName": "Manage Order fulfillment",
                                                "LevelID": "R02.05.04.16.02.07"
                                            },
                                            {
                                                "LevelName": "Evaluate and Refine Price Setting�",
                                                "LevelID": "R02.05.04.16.02.08"
                                            },
                                            {
                                                "LevelName": "Transfer Goods between Warehouses",
                                                "LevelID": "R02.05.04.16.02.09"
                                            },
                                            {
                                                "LevelName": "Manage Product Availability",
                                                "LevelID": "R02.05.04.16.02.10"
                                            },
                                            {
                                                "LevelName": "Manage Transfer Orders between Warehouses",
                                                "LevelID": "R02.05.04.16.02.11"
                                            },
                                            {
                                                "LevelName": "Manage Fulfillment of Order from Store (for orders taken via Online/Mobile/Etc)",
                                                "LevelID": "R03.05.04.16.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Direct Returns to DC (Customer to DC)",
                                        "LevelID": "05.04.16.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Send Invoice/ Credit Note per Preferred Method",
                                                "LevelID": "R01.05.04.16.03.03"
                                            },
                                            {
                                                "LevelName": "Manage Direct Returns to DC (Customer to DC)",
                                                "LevelID": "R02.05.04.16.03.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Direct Fulfillment of Orders from DC to Customer",
                                        "LevelID": "05.04.16.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Direct Fulfillment of Orders from DC to Customer",
                                                "LevelID": "R03.05.04.16.04.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Returns to Stores",
                                        "LevelID": "05.04.16.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Returns to Stores (Sold Online, Return at Store)",
                                                "LevelID": "R03.05.04.16.05.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Catalog Management",
                                "LevelID": "05.04.17",
                                "Level4Data": [
                                    {
                                        "LevelName": "Catalog Management",
                                        "LevelID": "05.04.17.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Process Call center Catalog",
                                                "LevelID": "R02.05.04.17.01.02"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "LevelName": "Manage Digital Operations",
                        "LevelID": "05.06",
                        "Level3Data": [
                            {
                                "LevelName": "Customer Browse and Order Entry",
                                "LevelID": "05.06.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Order Capturing",
                                        "LevelID": "05.06.01.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain Shopping Cart",
                                                "LevelID": "R02.05.06.01.03.01"
                                            },
                                            {
                                                "LevelName": "Manage Order Capturing",
                                                "LevelID": "R02.05.06.01.03.02"
                                            },
                                            {
                                                "LevelName": "Manage Order Capturing with Guest Account",
                                                "LevelID": "R02.05.06.01.03.03"
                                            },
                                            {
                                                "LevelName": "Search/Filters products by customer",
                                                "LevelID": "R03.05.06.01.03.04"
                                            },
                                            {
                                                "LevelName": "Perform payment by Customer",
                                                "LevelID": "R03.05.06.01.03.05"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Account and Profile Management",
                                        "LevelID": "05.06.01.04",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Customer Account and Data",
                                                "LevelID": "R03.05.06.01.04.01"
                                            },
                                            {
                                                "LevelName": "Register Account/Profile",
                                                "LevelID": "R03.05.06.01.04.02"
                                            },
                                            {
                                                "LevelName": "Maintain Account/Profile",
                                                "LevelID": "R03.05.06.01.04.03"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Gifting",
                                        "LevelID": "05.06.01.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Gift Card/Certificate",
                                                "LevelID": "R02.05.06.01.07.02"
                                            },
                                            {
                                                "LevelName": "Manage Wish Lists",
                                                "LevelID": "R03.05.06.01.07.04"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Ecommerce Fraud Prevention",
                                "LevelID": "05.06.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage eCommerce order management criteria",
                                        "LevelID": "05.06.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage discount and promotion",
                                                "LevelID": "R02.05.06.02.02.01"
                                            },
                                            {
                                                "LevelName": "Establish ship-to address restrictions",
                                                "LevelID": "R02.05.06.02.02.03"
                                            },
                                            {
                                                "LevelName": "Establish order value limits",
                                                "LevelID": "R03.05.06.02.02.02"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Ecommerce Merchandising Execution",
                                "LevelID": "05.06.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage promotional Copy",
                                        "LevelID": "05.06.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage promotional Copy",
                                                "LevelID": "R03.05.06.03.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Global and Category Pages",
                                        "LevelID": "05.06.03.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Global and Category Pages",
                                                "LevelID": "R02.05.06.03.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage E-Commerce Catalog",
                                        "LevelID": "05.06.03.07",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage E-Commerce Catalog",
                                                "LevelID": "R02.05.06.03.07.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Manage Multi Channel Payment Options",
                                "LevelID": "05.06.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Manage Merchant Accounts (Payment Gateways)",
                                        "LevelID": "05.06.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Merchant Accounts (Payment Gateways)",
                                                "LevelID": "R03.05.06.04.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Digital Marketing",
                                "LevelID": "05.06.05",
                                "Level4Data": [
                                    {
                                        "LevelName": "Loyalty Programs",
                                        "LevelID": "05.06.05.05",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Loyalty Programs",
                                                "LevelID": "R02.05.06.05.05.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "LevelName": "Retail Data Management",
                "LevelID": "06",
                "Level2Data": [
                    {
                        "LevelName": "Product Information Management",
                        "LevelID": "06.02",
                        "Level3Data": [
                            {
                                "LevelName": "Item Management",
                                "LevelID": "06.02.01",
                                "Level4Data": [
                                    {
                                        "LevelName": "Create a Product (single and mass update)",
                                        "LevelID": "06.02.01.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Create a Product",
                                                "LevelID": "R03.06.02.01.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Manage Retail Product (single and mass update)",
                                        "LevelID": "06.02.01.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Manage Retail Product",
                                                "LevelID": "R03.06.02.01.02.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Set up Retail Category Hierarchy",
                                        "LevelID": "06.02.01.03",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up Retail Category Hierarchy",
                                                "LevelID": "R02.06.02.01.03.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Providing Product Attributes",
                                "LevelID": "06.02.02",
                                "Level4Data": [
                                    {
                                        "LevelName": "Set up product attributes",
                                        "LevelID": "06.02.02.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Set up product attributes",
                                                "LevelID": "R01.06.02.02.01.01"
                                            }
                                        ]
                                    },
                                    {
                                        "LevelName": "Maintain Product Attributes",
                                        "LevelID": "06.02.02.02",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Providing Product Attributes",
                                                "LevelID": "R01.06.02.02.02.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Provisioning Product configuration",
                                "LevelID": "06.02.03",
                                "Level4Data": [
                                    {
                                        "LevelName": "Provisioning Product Configuration",
                                        "LevelID": "06.02.03.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Provisioning Product Configuration",
                                                "LevelID": "R01.06.02.03.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Managing Product Bundling",
                                "LevelID": "06.02.04",
                                "Level4Data": [
                                    {
                                        "LevelName": "Maintain Products Bundling",
                                        "LevelID": "06.02.04.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Maintain Products Bundling",
                                                "LevelID": "R02.06.02.04.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Managing Cross Sell and Up Sell Rules",
                                "LevelID": "06.02.05",
                                "Level4Data": [
                                    {
                                        "LevelName": "Managing Cross Sell and Up Sell Rules",
                                        "LevelID": "06.02.05.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Managing Cross Sell and Up Sell Rules",
                                                "LevelID": "R03.06.02.05.01.01"
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "LevelName": "Product Cross Reference ＆ Replacement",
                                "LevelID": "06.02.06",
                                "Level4Data": [
                                    {
                                        "LevelName": "Product Cross Reference ＆ Replacement",
                                        "LevelID": "06.02.06.01",
                                        "Level5Data": [
                                            {
                                                "LevelName": "Product Cross Reference ＆ Replacement",
                                                "LevelID": "R03.06.02.06.01.01"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ];
        
        let BusinessProcessData=[];
        
         for(let l1 in this.newData) //level one
         {
             let item1=this.newData[l1];
             BusinessProcessData.push({value: item1.LevelID, text:item1.LevelName,badge:'0',enabled:'',selected:'',link:''});
             if(item1.Level2Data != undefined)
             {
                 for(let l2 in item1.Level2Data) // level 2
                 {
                     let item2=item1.Level2Data[l2];
                     BusinessProcessData.push({value: item2.LevelID, text:item2.LevelName,badge:item1.LevelID,enabled:'',selected:'',link:''});
                     if(item2.Level3Data != undefined)
                     {
                         for(let l3 in item2.Level3Data) // level 3
                         {
                             let item3=item2.Level3Data[l3];
                             BusinessProcessData.push({value: item3.LevelID, text:item3.LevelName,badge:item2.LevelID,enabled:'',selected:'',link:''});    
                             if(item3.Level4Data != undefined)
                             {
                                 for(let l4 in item3.Level4Data) // level 4
                                 {
                                    let item4=item3.Level4Data[l4];
                                     BusinessProcessData.push({value: item4.LevelID, text:item4.LevelName,badge:item3.LevelID,enabled:'',selected:'',link:''});
                                     if(item4.Level5Data != undefined)
                                     {
                                         for(let l5 in item4.Level5Data)
                                         {
                                             let item5=item4.Level5Data[l5];
                                             BusinessProcessData.push({value: item5.LevelID, text:item5.LevelName,badge:item4.LevelID,enabled:'',selected:'',link:''});
                                            
                                         }
                                     }
                                    
                                 }
                             }
                            
                         }
                        
                     }
                    
                 }

             }           
            
         }
         debugger;
         let parent='0';
         let searchData=JSON.parse(JSON.stringify(this.newformat));
         let keys = Object.keys(searchData).length;
         //alert(keys);
         if (keys > 0) {
            for (let entry of searchData) {
               // this.refactorData(entry);
                    this.fillXdListData(entry,parent);
            }
         }
        console.log("individula level id's");
        console.log(BusinessProcessData);
        this.listData=BusinessProcessData;

        this.transformData = JSON.parse(JSON.stringify(this.newData).split('"LevelName":').join('"label":'));
        this.transformData = JSON.parse(JSON.stringify(this.transformData).split('"Level1Data":').join('"subs":'));
        this.transformData = JSON.parse(JSON.stringify(this.transformData).split('"Level2Data":').join('"subs":'));
        this.transformData = JSON.parse(JSON.stringify(this.transformData).split('"Level3Data":').join('"subs":'));
        this.transformData = JSON.parse(JSON.stringify(this.transformData).split('"Level4Data":').join('"subs":'));
        this.transformData = JSON.parse(JSON.stringify(this.transformData).split('"Level5Data":').join('"subs":'));

        this.data = JSON.parse(JSON.stringify(this.transformData));

        //    let ids = ["Supply to Customer"];
        //     this.filteredData = this.transformData.filter((item: any) => ids.indexOf(item.label) === 0);
        //     console.log("----------"+this.filteredData);

        //     this.data = this.filteredData;

        console.log("this.transformData" + JSON.stringify(this.transformData));

    }

    //this.BusinessProcessData=maptaxonomyDataToBusinessProcess(this.data);




    ngOnInit() {
    }


    private sourceData: models.BPSearch[] = [];

    public refactorData(data: any) {
        let keysArr: string[];
        keysArr = Object.keys(data);
        if (keysArr.length > 0) {
            for (let i = 0; i < keysArr.length; i++) {
                let key: string = keysArr[i];
                let tempUser = new models.BPSearch();
                tempUser.levelid = key.substr(0, key.indexOf(' '));
                tempUser.itemname = key.substr(key.indexOf(' ') + 1);
                tempUser.parentid="";
                if (tempUser != undefined)
                    tempUser.children = this.refactorData(data[key]);
                this.listofSearchItems.push(tempUser);
            }
        } else {

        }
        return  this.listofSearchItems;
    }



    public fillXdListData(data: any,parent:any) {
       
            console.log(data);
            for (let l1 in data) //1st level
                {
                    // All firest level will come
    
                    let Level1ID = l1.substr(0, l1.indexOf(' ')); // "03"
                    let Level1Name = l1.substr(l1.indexOf(' ') + 1);    // Level Name
                    let level2 = data[l1];
                    let level2_values = [];
                    
                    if (level2 != undefined) {
                        for (let l1 in level2) //1st level
                            {
                                //level2_values.push({ levelid: Level1ID, itemname: Level1Name,parentid:parent, children: level2 });
                                this.fillXdListData(level2,Level1ID);
                                this.listofSearchItems.push(new models.BPSearch({levelid: Level1ID, itemname: Level1Name,parentid:parent,children:level2})); //key
                            }

                   
                    }
                   

                } // 1, "string", false
        
        //alert(keys);
        // if (keys > 0) {
        //     for (let l1 in data) //1st level
        //         {
        //             // All firest level will come
    
        //             let Level1ID = l1.substr(0, l1.indexOf(' ')); // "03"
        //             let Level1Name = l1.substr(l1.indexOf(' ') + 1);    // Level Name
        //             let level2 = data[l1];
        //             if (level2 != undefined) {
        //                 this.listofSearchItems.push(new models.BPSearch({levelid: Level1Name, itemname: Level1Name,parentid:'0',children:level2})); //key
                   
        //             }

        //         }
        // }
    }
   
    private IsExpanded: any;
    toggle() {
        this.IsExpanded = !this.IsExpanded;
    }
    public maptaxonomyDataToBusinessProcess(data: any) {
        // Transform code start from here 
        let BusinessProcessData = [];
        console.log("From taxonomy data");
        console.log(data);

        let keys = Object.keys(data).length;
        //alert(keys);
        if (keys > 0) {

            let level2_values = []; let level3_values = []; let level4_values = []; let level5_values = [];


            for (let l1 in data) //1st level
            {
                // All firest level will come

                let Level1ID = l1.substr(0, l1.indexOf(' ')); // "03"
                let Level1Name = l1.substr(l1.indexOf(' ') + 1);    // Level Name

                let tmp_values = [];
                let level2 = data[l1];
                if (level2 != undefined) {
                    level2_values = [];
                    for (let l2 in level2) // 2nd level 
                    {
                        let Level2ID = l2.substr(0, l2.indexOf(' ')); // "03.02"
                        let Level2Name = l2.substr(l2.indexOf(' ') + 1);

                        let level3 = level2[l2];
                        if (level3 != undefined) {
                            level3_values = [];
                            for (let l3 in level3)  // 3rd level 
                            {
                                let Level3ID = l3.substr(0, l3.indexOf(' ')); // "03.02.01"
                                let Level3Name = l3.substr(l3.indexOf(' ') + 1);

                                let level4 = level3[l3];
                                if (level4 != undefined) {
                                    level4_values = [];
                                    for (let l4 in level4) // 4th level
                                    {
                                        let Level4ID = l4.substr(0, l4.indexOf(' ')); // "03.02.01.01"
                                        let Level4Name = l4.substr(l4.indexOf(' ') + 1);

                                        let level5 = level4[l4];
                                        if (level5 != undefined) {
                                            level5_values = [];
                                            for (let l5 in level5) // 5th level
                                            {
                                                let Level5ID = l5.substr(0, l5.indexOf(' ')); // "R01.03.02.01.01.02"
                                                let Level5Name = l5.substr(l5.indexOf(' ') + 1);
                                                level5_values.push({ LevelName: Level5Name, LevelID: Level5ID });
                                            }
                                        }

                                        if (level5_values.length > 0)
                                            level4_values.push({ LevelName: Level4Name, LevelID: Level4ID, Level5Data: level5_values });
                                        else
                                            level4_values.push({ LevelName: Level4Name, LevelID: Level4ID });

                                    }
                                }
                                if (level4_values.length > 0)
                                    level3_values.push({ LevelName: Level3Name, LevelID: Level3ID, Level4Data: level4_values });
                                else
                                    level3_values.push({ LevelName: Level3Name, LevelID: Level3ID });
                            }
                        }

                        if (level3_values.length > 0) // if level 3 data available 
                            level2_values.push({ LevelName: Level2Name, LevelID: Level2ID, Level3Data: level3_values });
                        else
                            level2_values.push({ LevelName: Level2Name, LevelID: Level2ID });
                    }
                }

                BusinessProcessData.push({ LevelName: Level1Name, LevelID: Level1ID, Level2Data: level2_values });
            }
            console.log(BusinessProcessData);

            return BusinessProcessData;
        }

        // end

        // Transform the data here and send data back to component

    }
   public  searchingEvent = (page: Searching) => {
        debugger;
        console.log('page.fromIndex');
        console.log(page.showTile);
        this.showTile=page.showTile;

    }
    public filterNames(listofSearchItems:models.BPSearch[]){
        for (let l1 in listofSearchItems) //1st level
            {
                let item = listofSearchItems[l1];
                if (item != undefined) {
                    if(item.itemname!=undefined)
                        {

                if(item.itemname.includes(this.test)){
                //     this.filteredListData.push({
                //    id: item.levelid, name: item.itemname
                //   });  

                  this.filteredListData.push({value: item.levelid, text:item.itemname,badge:'0',enabled:'',selected:'',link:'' }); 


                 }
                 if(item.children){
                    this.filterNames(item.children);
                   }
                }
            }
            }
     
       }

    

    
   

}
