import { Component, OnInit,Input } from '@angular/core';
import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

import {SearchFilterPipe} from '../../../shared/pipes/filter.pipe';

import { Subject } from 'rxjs/Subject';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';  //<<<< import it here
@Component({
  selector: 'app-business-detail',
  templateUrl: './business-detail.component.html',
  styleUrls: ['./business-detail.component.scss']
})
export class BusinessDetailComponent implements OnInit {

  previewCnt: any;
  tabList : any = [];
  characters = [
    'Finn the human',
    'Jake the dog',
    'Princess bubblegum',
    'Lumpy Space Princess',
    'Beemo1',
    'Beemo2'
  ]
  public clickTabs:any;
  @Input() subSiteName:string;

  constructor(private _industryService : IndustryService) { 

     
  }

  ngOnInit() {

        /*this.tabList.push({ name : 'Preview', count:1});
        this.tabList.push({ name : 'Strategies', count:this.previewCnt});
        this.tabList.push({ name : 'Activities', count:this.previewCnt});
        this.tabList.push({ name : 'Accelerators', count:this.previewCnt});
        this.tabList.push({ name : 'Assets', count:this.previewCnt}); */       
}

/*tabChanged($event: any) {
    this.clickTabs = $event;
}*/


}
