import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-business-overview',
  templateUrl: './business-overview.component.html',
  styleUrls: ['./business-overview.component.scss']
})
export class BusinessOverviewComponent implements OnInit {

  @Input() lomView: String;
  @Input() e2eView: String;
  
  businessOverviewTabList : any[] = [];
  businessOverviewTileList :any []= [];
  
  tileType : string;
  Clickedtab: string;

  constructor() { 

    this.Clickedtab ="LOM View";

  } 

  ngOnInit() {

    this.businessOverviewTabList.push({ name  : 'LOM View' }, { name  :  'E2E View'});

    //TODO : remove sample data and retrieve data from service instead
    //sample data to display
    /*this.businessOverviewTileList.push(
      { 
        title : 'LOM View', 
        subTitle : '', 
        description : '', 
        imageUrl : '/sites/AIES/SiteAssets/publish/assets/images/Retail LOM.png', //TODO : provide sample image
        tileType : 'fullwidth'
      },
      { 
        title : 'E2E View', 
        subTitle : '', 
        description : '', 
        imageUrl : '/sites/AIES/SiteAssets/publish/assets/images/Retail E2E.png', //TODO : provide sample image
        tileType : 'fullwidth'
      }
    );*/

        //this.tileType = 'fullwidth';
  }

tabChanged($event: any) {
    this.Clickedtab=$event;
  }

}
