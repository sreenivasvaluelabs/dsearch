import { Component, OnInit,Input,ViewEncapsulation } from '@angular/core';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

declare var myExtObject: any;

@Component({
  selector: 'app-business-process',
  templateUrl: './business-process.component.html',
  styleUrls: ['./business-process.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BusinessProcessComponent implements OnInit {

  public activitiesDetails: Array<models.BusinessProcessActivities>;
  public assestDetails: Array<models.BusinessProcessAssets>;
  public accelaratorDetails: Array<models.BusinessPorcessAccelerator>;
  public activitiesDetailData: any;
  public businessStrategyDetails: Array<models.BusinessPorcessMapping>;
  public assestDetailData: any;
  public accelaratorDetailData: any;
  public businessStrategyDetailData: any;
  public businessProcessDetailData: any;
  public businessProcessDetails: Array<models.BusinessProcessDetail>;
  public processLevel: string;
  public processTabType: string;
  public clickTabs: any;
  public businessPorcessItems: Array<any>;

  @Input() subSiteName:string;
  businessProcessTablist: any = [];

  constructor(private _industryService : IndustryService) { 

    this.businessStrategyDetails = new Array<models.BusinessPorcessMapping>();
    this.assestDetails = new Array<models.BusinessProcessAssets>();
    this.accelaratorDetails = new Array<models.BusinessPorcessAccelerator>();
    this.activitiesDetails = new Array<models.BusinessProcessActivities>();
    this.businessProcessDetails = new Array<models.BusinessProcessDetail>();

      this.clickTabs = "staggerdview";
}

  ngOnInit() {
        debugger;
        this.subSiteName = "Retail";

        this.businessProcessTablist = [
              { "name": "staggerdview" }, { "name": "tableview" },
              { "name": "treeview" },
        ];
        
            // Calling JS function
            //console.log("Calling Javascript Detail - ");
            // this.businessPorcessItems = myExtObject.getBusinessProcessDataAll(this.subSiteName)
            // this._industryService.businessPorcessItemsData = this.businessPorcessItems
             
         /*  this._industryService.GetBusinessProcessData(this.subSiteName).subscribe(result => {

                  this.businessPorcessItems = result;

                  console.log("Inside Calling Function");
                  console.log( this.businessPorcessItems);
              });*/
                   /* .then((result) => {
                    this.businessPorcessItems = result;
                      console.log("Inside Calling Function");
                      console.log( this.businessPorcessItems);
                  });*/
            
            
          /* myExtObject.getBusinessProcessDataAll(this.subSiteName).then((result) => {
              this.businessPorcessItems = result;
           });*/
             
         /*    setTimeout(
                function() { 

                        console.log("After Service retrun data1");
                        console.log(data);

             }, 15000);*/
            //this.businessPorcessItems = this._industryService.GetBusinessProcessData("Retail");
            
            //console.log("After Service retrun data");
            //console.log(this.businessPorcessItems);

                // checking the business process details data exist in service varables else hitting the service
                if (this._industryService.businessProcessDetailsData != null || this._industryService.businessProcessDetailsData != undefined) {
                  if (this._industryService.businessProcessDetailsData.length > 0) {
                    this.businessProcessDetails = this._industryService.businessProcessDetailsData;
                  }

                  else {
                    this._industryService.GetBusinessProcessDetailData(this.subSiteName).subscribe(y => {
                      this.businessProcessDetailData = y;
                      if (this.businessProcessDetailData != null || this.businessProcessDetailData.lenght != undefined) {
                        this.businessProcessDetails = this.mapBusinessProcessDetailComponentData();
                        this._industryService.businessProcessDetailsData = this.businessProcessDetails;
                      }

                    });
                  }
                }
            // checking the business activities details  data exist in service variables else hitting the service
                if (this._industryService.activitiesDetailsData != null || this._industryService.activitiesDetailsData != undefined) {
                  if (this._industryService.activitiesDetailsData.length > 0) {
                    this.activitiesDetails = this._industryService.activitiesDetailsData;
                  }

                  else {
                    this._industryService.GetBusinessProcessActivites(this.subSiteName).subscribe(y => {
                      this.activitiesDetailData = y;
                      if (this.activitiesDetailData != null || this.activitiesDetailData.length != undefined) {
              
                        this.activitiesDetails = this.mapBusinessProcessActivitiesComponentData();
                        this._industryService.activitiesDetailsData = this.activitiesDetails;
                      }

                    });
                  }
                }
            // checking the business Strategy Details data exist in service variables else hitting the service

                if (this._industryService.businessStrategyDetailsData != null || this._industryService.businessStrategyDetailsData != undefined) {
                  if (this._industryService.businessStrategyDetailsData.length > 0) {
                    this.businessStrategyDetails = this._industryService.businessStrategyDetailsData;
                  }

                  else {
                    this._industryService.GetStratagyOverview(this.subSiteName).subscribe(y => {
                      this.businessStrategyDetailData = y;
                      if (this.businessStrategyDetailData != null || this.businessStrategyDetailData.lenght != undefined) {
                        this.businessStrategyDetails = this.mapBusinessStrategyDetailComponentData();
                        this._industryService.businessStrategyDetailsData = this.businessStrategyDetails;
                      }

                    });
                  }
                }

            // checking the business assest Details data exist in service variables else hitting the service

             if (this._industryService.assestDetailsData != null || this._industryService.assestDetailsData != undefined) {
                  if (this._industryService.accelaratorDetailsData.length > 0) {
                    this.assestDetails = this._industryService.assestDetailsData;
                    this.accelaratorDetails = this._industryService.accelaratorDetailsData;
                  }
                  else {
                    this._industryService.getAssestAccelaratorcode(this.subSiteName).subscribe(y => {
                      this.assestDetailData = y;
                      this.accelaratorDetailData = y;
                      if (this.assestDetailData != null || this.assestDetailData.lenght != undefined) {
                        this.assestDetails = this.mapAssetDetailComponentData("Asset");
                        if (this.assestDetails != undefined)
                          this._industryService.assestDetailsData = this.assestDetails;
                      }
                      this.accelaratorDetailData = y;
                      if (this.accelaratorDetailData != null || this.accelaratorDetailData.lenght != undefined) {
                        this.accelaratorDetails = this.mapAssetDetailComponentData("Accelarator");
                        if (this.accelaratorDetails != undefined)
                          this._industryService.accelaratorDetailsData = this.accelaratorDetails;
                      }

                    });
                  }
                }
              /*if (this._industryService.assestDetailsData != null || this._industryService.assestDetailsData != undefined) 
              {
                  this.assestDetails = this._industryService.assestDetailsData;
              }
              else 
              {
                    this._industryService.getAssestAccelaratorcode(this.subSiteName).subscribe(y => {
                      this.assestDetailData = y;
                      if (this.assestDetailData != null || this.assestDetailData.lenght != undefined) {
                          this.assestDetails = this.mapAssetDetailComponentData("Asset");
                        if (this.assestDetails != undefined)
                          this._industryService.assestDetailsData = this.assestDetails;
                      }
                    });
               }

              if (this._industryService.accelaratorDetailsData != null || this._industryService.accelaratorDetailsData != undefined) 
              {
                  this.accelaratorDetails = this._industryService.accelaratorDetailsData;
              }
              else
              {
                      this._industryService.getAssestAccelaratorcode(this.subSiteName).subscribe(y => {
                     this.accelaratorDetailData = y;
                      if (this.accelaratorDetailData != null || this.accelaratorDetailData.lenght != undefined) {
                        this.accelaratorDetails = this.mapAssetDetailComponentData("Accelarator");
                        if (this.accelaratorDetails != undefined)
                          this._industryService.accelaratorDetailsData = this.accelaratorDetails;
                      }
                    });
                    
              }*/
                
}

public getdata(){
  var promise = new Promise(function(resolve, reject) {
     window.setTimeout(function() 
     {
        myExtObject.getBusinessProcessDataAll(this.subSiteName);
     }, 15000);
   });
   return promise;
}

tabChanged($event: any) {
    this.clickTabs=$event; // this will have tab name when clicked on the tabs
    console.log("Click")
    console.log(this.clickTabs);
  }

private mapBusinessProcessDetailComponentData() : Array<models.BusinessProcessDetail> {
    //let resultsDD=this.businessProcessDetailData.d.results;
    let resultsDD=this.businessProcessDetailData.value;
    
    if(resultsDD!=undefined && resultsDD.length>0){
    
         for(let i in resultsDD){
             let item=resultsDD[i]; 
             let LevelID ="";
             let LevelName="";
             if(item.Business_x0020_Process_x0020_Hie != undefined)
             {
                 let metadata=item.Business_x0020_Process_x0020_Hie;                            
                 let level=metadata[0].Label;
                 level=level.split(":");                            
                 let level1=level[level.length-1]; 
                 LevelID =level1.substr(0,level1.indexOf(' ')); // "03.02.01.01"
                 LevelName=level1.substr(level1.indexOf(' ')+1);                            
             }              
             if(LevelID != '')
             {                          
                 this.businessProcessDetails.push({processID:item.BP_x0020_Process_x0020_ID,name:item.BP_x0020_Name,type:item.BP_x0020_Type,status:item.BP_x0020_Status,scoping:item.Scoping,description:item.Ava_Description,businessProcessLevelId:LevelID,owner:item.Owner.Title,businessProcessname:LevelName,area:item.BP_x0020_Area});       
             }
         }
         return this.businessProcessDetails;
     }

  }
private mapBusinessProcessActivitiesComponentData() : Array<models.BusinessProcessActivities> 
{
    //let resultsDD=this.activitiesDetailData.d.results;
    let resultsDD=this.activitiesDetailData.value;
    if(resultsDD!=undefined && resultsDD.length>0)
    {
        
        for(let i in resultsDD)
        {            
            let item=resultsDD[i];                  
            let LevelID ="";
            let LevelName="";
            if(item.Business_x0020_Process_x0020_Hie.results != undefined)
            {
                let metadata=item.Business_x0020_Process_x0020_Hie.results;                         
                let level=metadata[0].Label;
                level=level.split(":");                         
                let level1=level[level.length-1]; 
                LevelID =level1.substr(0,level1.indexOf(' ')); // "03.02.01.01"
                LevelName=level1.substr(level1.indexOf(' ')+1); // Level Name                       
            }                
            this.activitiesDetails.push({businessProcessLevelId:LevelID,activityName:item.Activity_x0020_name,activityType:item.Activity_x0020_type,application:item.Application,Id:item.ID,lane:item.Lane,recordingType:item.Recording_x0020_type});                       
        }   
        console.log("Activities Data :");
        console.log(this.activitiesDetails); 
        return this.activitiesDetails;                          
    }
}
private mapAssetDetailComponentData(toolType:string) : Array<models.BusinessProcessAssets> 
{
            
            let resultsDD;
            
            if(toolType == 'Asset')
            {
                //resultsDD=this.assestDetailData.d.results;
                resultsDD=this.assestDetailData.value;

            }
            else
            {
                //resultsDD=this.accelaratorDetailData.d.results;
                resultsDD=this.accelaratorDetailData.value;

            } 

            if(resultsDD!=undefined && resultsDD.length>0){
                
            for(let i in resultsDD){
                
                let item=resultsDD[i];  
                
                let LevelID ="";
                let LevelName="";
                if(item.Business_x0020_Process_x0020_Hierarchy != undefined)
                {
                    let metadata=item.Business_x0020_Process_x0020_Hierarchy;                           
                    let level=metadata[0].Label;
                    level=level.split(":");                         
                    let level1=level[level.length-1]; 
                    LevelID =level1.substr(0,level1.indexOf(' ')); // "03.02.01.01"
                    LevelName=level1.substr(level1.indexOf(' ')+1);     // Level Name in case we need in future                     
                }   
    
                let AssestName="";
                if(item.File.Name != undefined) // document name // new code
                    AssestName=item.File.Name; // new code  

                // new code
                let filename = AssestName.lastIndexOf('.');
                let FirstName = AssestName.substring(0, filename); //before extention name
                let fileExtension = AssestName.substring(filename + 1); // file extention will return 
                let previewSrc = "";

                if(fileExtension == "vsdx")  
                {                               
                    previewSrc = item.ServerRedirectedEmbedUrl;
                }   
                
                let imageURL = "";

                let AssestDownloading="";
                if(item.FieldValuesAsText.FileRef != undefined) // for downloading perticular document need to pass this variable future use not now
                    AssestDownloading=item.FieldValuesAsText.FileRef;
    
                let Accelerator="";
                if(item.Accelerator_x0020_Name.Accelerator != undefined)
                    Accelerator=item.Accelerator_x0020_Name.Accelerator;
                    
                                            
                if(item.Asset_x0020_Type ==toolType)
                    this.assestDetails.push({assetId:item.ID,assetName:AssestName,phase: item.Phase,accelerator:Accelerator,description: item.Ava_Description,businessProcessLevelId:LevelID,previewSrc:previewSrc,imageIcon:imageURL});
                else
                    this.accelaratorDetails.push({assetId:item.ID,assetName:AssestName,phase: item.Phase,accelerator:Accelerator,description: item.Ava_Description,businessProcessLevelId:LevelID,previewSrc:previewSrc,imageIcon:imageURL});                            
            }
            if(toolType=='Asset')
                return this.assestDetails;
            else
                return this.accelaratorDetails;
        }
}
private mapBusinessStrategyDetailComponentData() : Array<models.BusinessPorcessMapping> 
{
    //let resultsDD=this.businessStrategyDetailData.d.results;
    let resultsDD=this.businessStrategyDetailData.value;
    if(resultsDD!=undefined && resultsDD.length>0){
        
             for(let i in resultsDD){
             
                     let item=resultsDD[i]; 
                     let LevelID ="";
                     let LevelName="";
                     if(item.Business_x0020_Process_x0020_Hie != undefined)
                     {
                         let metadata=item.Business_x0020_Process_x0020_Hie;                            
                         let level=metadata[0].Label;
                         level=level.split(":");                            
                         let level1=level[level.length-1]; 
                         LevelID =level1.substr(0,level1.indexOf(' ')); // "03.02.01.01"
                         LevelName=level1.substr(level1.indexOf(' ')+1);                            
                     }  
                     let GoalName="";
                     if(item.Goal.Goal_x0020_Name != undefined)
                         GoalName=item.Goal.Goal_x0020_Name;
                     
                     let MetricName="";
                     if(item.Metric.Metric_x0020_Name != undefined)
                         MetricName=item.Metric.Metric_x0020_Name;
                     this.businessStrategyDetails.push({businessProcessLevelId:LevelID,businessProcessLevelname:LevelName,goalName:GoalName,metricsName:MetricName,notes:item.Notes1,Id:item.ID});
                 }
                return this.businessStrategyDetails
             }
}  
}
