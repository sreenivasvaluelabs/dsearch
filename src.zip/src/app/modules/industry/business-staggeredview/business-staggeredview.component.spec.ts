import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessStaggeredviewComponent } from './business-staggeredview.component';

describe('BusinessStaggeredviewComponent', () => {
  let component: BusinessStaggeredviewComponent;
  let fixture: ComponentFixture<BusinessStaggeredviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessStaggeredviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessStaggeredviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
