import { Component, OnInit, Input, NgZone } from '@angular/core';
import { stagger } from '@angular/core/src/animation/dsl';

@Component({
   selector: 'app-business-staggeredview',
   templateUrl: './business-staggeredview.component.html',
   styleUrls: ['./business-staggeredview.component.scss']
})
export class BusinessStaggeredviewComponent implements OnInit {

   private activePage: any;
   public businessCategory: any;
   item: number;
   selected: any;

   public staggeredData: any;
   public staggerWidth: any;
   public staggerItemWidth: any;
   public staggerIndex: number = 0;
   public staggerMargin: any;
   public staggerShow: any;
   public width: any;
   
   @Input() staggerCount: number;
   @Input() subSiteName:string;

   indexCouter(counter: any, data: any) {
      if (counter < this.staggerCount - 1) {
         this.staggerIndex = counter + 1;
         this.staggerShow = this.staggerIndex;
         if (this.staggerIndex < this.staggerCount) {
            this.staggerMargin = '-' + this.staggerIndex * 100 + '%';
         }
      }

   };
   backCouter(counter: any, data: any) {
      if (counter > 0) {
         this.staggerIndex = counter - 1;
         this.staggerShow = this.staggerIndex;
         this.staggerMargin = '-' + this.staggerIndex * 100 + '%';
      }
   }


   constructor(ngZone: NgZone) {

      window.onresize = (e) => {
         ngZone.run(() => {
            this.staggerShow = 0;
            this.width = window.innerWidth;
            if (this.width < 992) {
               this.staggerWidth = this.staggerCount * 100 + '%';
               this.staggerItemWidth = 100 / this.staggerCount + '%';
            }
            else {
               this.staggerWidth = 100 + '%';
               this.staggerMargin = 0;
            }
         });
      };


      this.staggeredData = [
         {
            "catgoryTitle": "Platform name",
            "categories": [
               {
                  "subCatgoryTitle": "Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               },
               {
                  "subCatgoryTitle": "Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               }
            ]
         },
         {
            "catgoryTitle": "Sub Platform name",
            "categories": [
               {
                  "subCatgoryTitle": "Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               }
            ]
         },
         {
            "catgoryTitle": "Process name",
            "categories": [
               {
                  "subCatgoryTitle": "Process Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               },
               {
                  "subCatgoryTitle": "Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               }
            ]
         },
         {
            "catgoryTitle": "Process Details",
            "categories": [
               {
                  "subCatgoryTitle": "Process Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               },
               {
                  "subCatgoryTitle": "Strategy",
               },
               {
                  "subCatgoryTitle": "buy",
               }
            ]
         }
      ]
   }

   ngOnInit() {
      this.staggerShow = this.staggerIndex;
      this.width = window.innerWidth;
      if (this.width < 992) {
         this.staggerWidth = this.staggerCount * 100 + '%';
         this.staggerItemWidth = 100 / this.staggerCount + '%';
      }
      this.staggerShow = 0;
   }

   select(item: any) {
      this.selected = item;
      console.log(this.selected);
   };
   isActive(item: any) {
      return this.selected === item;
   };




}