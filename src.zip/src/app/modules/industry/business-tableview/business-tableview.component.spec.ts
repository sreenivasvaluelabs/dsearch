import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessTableviewComponent } from './business-tableview.component';

describe('BusinessTableviewComponent', () => {
  let component: BusinessTableviewComponent;
  let fixture: ComponentFixture<BusinessTableviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessTableviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessTableviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
