import { Component, OnInit,Input } from '@angular/core';
import * as models from '../../../service/_models'; 
import { PagerService } from '../../../service/_services/pager.service';
import { IndustryService } from '../../../service/_services/industry.service';
import { SortComponent } from '../../../shared/components/xd-sort/xd-sort.component';
import { SortUtil, SortOn, SortType } from '../../../shared/components/xd-sort/xd-sort.component';
import {OrderrByPipe} from '../../../shared/pipes/orderby.pipe';
import {  Paging } from '../../../shared/components/xd-pager/xd-pager.component';
//import {  Paging1 } from '../../../shared/components/xd-search/xd-search.component';
import {  ViewContainerRef, ComponentFactoryResolver, ViewChild, ComponentRef } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
class Record {
  
      constructor(public ID: number, public Firstname: string, public Lastname: string) {
      }
  
  
  }
@Component({
  selector: 'app-business-tableview',
  templateUrl: './business-tableview.component.html',
  styleUrls: ['./business-tableview.component.scss'],
  providers : [OrderrByPipe,SortUtil]


})
export class BusinessTableviewComponent {
  @Input() subSiteName:string;
    displayRecords: Record[];
    filteredRecords: Record[];
    title: string = "Paging, sorting and filtering"
    recordCount: number;

    private allRecords: Record[];
    
    constructor(private _sortUtil: SortUtil ) {
      
        this.allRecords = [];
        var lasts: string[] = ["Friday", "Nguyen", "Ho", "Martinez", "Lee", "Ly", "Tran", "Mac", "Job", "Gate", "Bush", "Cliton"];
        var Firsts: string[] = ["Julie", "Cater", "Leo", "Jose", "kimberly", "Nick", "Steven", "Tony", "Mike", "Linh", "Cater", "Ted"];
        for (var i = 1; i < 1500; ++i) {
            var l: number = (Math.random() * lasts.length) | 0;
            var f: number = (Math.random() * Firsts.length) | 0;
            var r = new Record(i, Firsts[f], lasts[l]);
            this.allRecords.push(r);
        }

        this.filteredRecords = this.allRecords;
        this.recordCount = this.filteredRecords.length;
        this.displayRecords = this.filteredRecords;
        alert(this.displayRecords);
      
    }
    pagingEvent = (page: Paging) => {
        debugger;
        var temp: Record[] = [];
        //this.records = this.records.slice(page.fromIndex, page.toIndex);
        //Using basic instead of slice, so that it is intutive to javascript/typescrip beginer.
        for (var i = page.fromIndex; i <= page.toIndex; ++i)
            temp.push(this.filteredRecords[i]);
        this.displayRecords = temp;

    }
      sorting = (s: SortOn): void => {
          debugger;
        this._sortUtil.SetSortOn(s);
        this._sortUtil.sort(this.displayRecords);

    }
 
}
