import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndustryAcceleratorsComponent } from './industry-accelerators.component';

describe('IndustryAcceleratorsComponent', () => {
  let component: IndustryAcceleratorsComponent;
  let fixture: ComponentFixture<IndustryAcceleratorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndustryAcceleratorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndustryAcceleratorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
