import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-industry-accelerators',
  templateUrl: './industry-accelerators.component.html',
  styleUrls: ['./industry-accelerators.component.scss']
})
export class IndustryAcceleratorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
