import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndustryAssetsComponent } from './industry-assets.component';

describe('IndustryAssetsComponent', () => {
  let component: IndustryAssetsComponent;
  let fixture: ComponentFixture<IndustryAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndustryAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndustryAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
