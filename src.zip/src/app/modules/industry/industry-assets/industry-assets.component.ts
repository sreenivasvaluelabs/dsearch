import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-industry-assets',
  templateUrl: './industry-assets.component.html',
  styleUrls: ['./industry-assets.component.scss']
})
export class IndustryAssetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
