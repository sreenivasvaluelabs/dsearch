import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndustrybannerComponent } from './industrybanner.component';

describe('IndustrybannerComponent', () => {
  let component: IndustrybannerComponent;
  let fixture: ComponentFixture<IndustrybannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndustrybannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndustrybannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
