import { Component, OnInit,Input } from '@angular/core';

import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

@Component({
  selector: 'app-industrybanner',
  templateUrl: './industrybanner.component.html',
  styleUrls: ['./industrybanner.component.scss']
})
export class IndustrybannerComponent implements OnInit {

  bannerSlide:any;
  industryOverviewDetails: any;
  industryDetailoverview : any =[];
  public industryHierachyDetails: Array<models.IndustryHierachy>;
  industrySolutionName: string;
  shortDescription: string;
  imageUrl: string;

  @Input() subSiteName:string;

  constructor(private _industryService : IndustryService) { 
    this.industryHierachyDetails = new Array<models.IndustryHierachy>();
  }

  ngOnInit() {

   // console.log("this.subSiteName in Banner");
    //console.log(this.subSiteName);

    this._industryService.GetIndustryOverview(this.subSiteName).subscribe(x => {
      this.industryOverviewDetails = x;
     // console.log(this.industryOverviewDetails);

      // SharePoint Testing
     this.industryHierachyDetails = this.mapIndustryOverviewComponentData();
     
    // console.log("Mapping Banner  Data-- this.industryHierachyDetails");
    // console.log(this.industryHierachyDetails);

          this.industryHierachyDetails.forEach((x:models.IndustryHierachy) => {

            this.bannerSlide = {
                "title": x.industrySolutionName,
                "description": x.shortDescription,
                "href": "",
                "imageurl": x.imageUrl
              }
            });
    });
    
   // Local Testing 
   //this.industryHierachyDetails = this.industryOverviewDetails ;

  

  }

  
  private mapIndustryOverviewComponentData(): Array<models.IndustryHierachy> {
    
        let ProcessCount=0;
        let TraininDoc=0;
        let TaskGuide=0;

       // console.log("mapIndustryOverviewComponentData");
       // console.log(this.industryOverviewDetails);
        
        //let resultsDD = this.industryOverviewDetails.d.results;
        let resultsDD = this.industryOverviewDetails.value;

         //console.log(resultsDD);

          if(resultsDD!=undefined && resultsDD.length>0){
            
                 for(let i in resultsDD){
                     let item=resultsDD[i];
                     //let metadata=item.Industry_x0020_Solution.results;
                     let metadata=item.Industry_x0020_Solution;   
                     let level=metadata[0].Label;
                     level=level.split(":");						
                     let IndustrySolution=level[2];
                     let imageURL="";
                     let LOM="";
                     let E2E="";
                     if(item.Image_x0020_URL !=null )
                         imageURL=item.Image_x0020_URL["Description"];	
                     if(item.LOM_x0020_Image_x0020_URL !=null )
                         LOM=item.LOM_x0020_Image_x0020_URL["Description"];	
                     if(item.E2E_x0020_Image_x0020_URL !=null )
                         E2E=item.E2E_x0020_Image_x0020_URL["Description"];						
                         this.industryDetailoverview.push({industrySolutionName:IndustrySolution,shortDescription:item.Short_x0020_Description,longDescription:item.Long_x0020_Description,imageUrl:imageURL,lomImageUrl: LOM,e2eImageUrl:E2E });					
                 }
            }
            
         this.industryHierachyDetails.push(new models.IndustryHierachy({industrySolutionName:this.industryDetailoverview[0].industrySolutionName,shortDescription:this.industryDetailoverview[0].shortDescription,longDescription:this.industryDetailoverview[0].longDescription,imageUrl:this.industryDetailoverview[0].imageUrl,lomImageUrl:this.industryDetailoverview[0].imageUrl,e2eImageUrl:this.industryDetailoverview[0].e2eImageUrl,countProcessFlow:ProcessCount, countTrainingDoc:TraininDoc,countTaskGuide:TaskGuide }));
         return this.industryHierachyDetails;
      }  
}
