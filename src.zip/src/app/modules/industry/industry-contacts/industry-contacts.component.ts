import { Component, OnInit,Input } from '@angular/core';
import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

@Component({
  selector: 'app-industry-contacts',
  templateUrl: './industry-contacts.component.html',
  styleUrls: ['./industry-contacts.component.scss']
})
export class IndustryContactsComponent implements OnInit {

  public industryContactsData : any;
  public industryContacts: Array<models.Contacts>;

  @Input() subSiteName:string;

  constructor(private _industryService : IndustryService) { }

  ngOnInit() {

              // Calling Goal Data
            this._industryService.GetContactsData(this.subSiteName).subscribe(y => {
                   this.industryContactsData=y;

              if(this.industryContactsData != null || this.industryContactsData.lenght != undefined)
              {
                  this.industryContacts=this.mapIndustryContacts();
                  this._industryService.industryContactsData = this.industryContacts;
              }

            });   
  }
public mapIndustryContacts() : Array<models.Contacts> 
  {
        // Transform code
        let contractsdata=[];
        let resultsDD=this.industryContactsData.d.results; 
                  
        if(resultsDD!=undefined && resultsDD.length>0){
        for(let i in resultsDD){     
                let item=resultsDD[i];              
                this.industryContacts.push({region:item.Contacts_x0020_Region,role:item.Role,displayName:item.Display_x0020_Name,imageUrl:item.Image_x0020_URL,email:item.Email.EMail});                       
            }                      
        }

        return this.industryContacts;
  }
}
