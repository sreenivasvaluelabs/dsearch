import { Component, OnInit,Input } from '@angular/core';

import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

@Component({
  selector: 'app-industry-overview',
  templateUrl: './industry-overview.component.html',
  styleUrls: ['./industry-overview.component.scss']
})
export class IndustryOverviewComponent implements OnInit {

  public overviewdata:any;
  industryCountDetails: any;
  public industryHierachyDetails: Array<models.IndustryHierachy>;
    countProcessFlow: number;
    countTrainingDoc: number;
    countTaskGuide: number;

  @Input() subSiteName:string;

  constructor(private _industryService : IndustryService) { 

  this.industryHierachyDetails = new Array<models.IndustryHierachy>();

  }

  ngOnInit() {
  
        //console.log("this.subSiteName in Overview");
       // console.log(this.subSiteName);

        // Get the tools and Acces from the Root Service 
            
        // End getting accelerator

        this._industryService.GetIndustryCount(this.subSiteName).subscribe(y => {
           this.industryCountDetails = y;
           
          // console.log(this.industryCountDetails);
           // SharePoint Testing
         this.industryHierachyDetails = this.mapIndustryOverviewComponentData();
         //console.log("after Mapping Industry Overview Data");
         //console.log(this.industryHierachyDetails);

             this.industryHierachyDetails.forEach((x:models.IndustryHierachy) => {

                this.overviewdata = [
                    {
                        "imageUrl": "/sites/AIES/SiteAssets/publish/assets/images/Process_Flow.svg",
                        "count": x.countProcessFlow,
                        "category": "Process Flows"
                    },
                    {
                        "imageUrl": "/sites/AIES/SiteAssets/publish/assets/images/Training-documents.svg",
                        "count": x.countTrainingDoc,
                        "category": "Training Document"
                    },
                    {
                        "imageUrl": "/sites/AIES/SiteAssets/publish/assets/images/Task_Guide.svg",
                        "count": x.countTaskGuide,
                        "category": "Task Guide"
                }];
    
            });

        });   

        
       

        // Local Testing 
        //this.industryHierachyDetails = this.industryCountDetails ;

       

  }

   private mapIndustryOverviewComponentData(): Array<models.IndustryHierachy> {

    let ProcessCount=0;
    let TraininDoc=0;
    let TaskGuide=0;
      
        //console.log("Industry Overview");
        //console.log(this.industryCountDetails);

        //let CountresultsDD=this.industryCountDetails.d.results;
        let CountresultsDD=this.industryCountDetails.value;

        //console.log("Mapping Industry Overview Data");
        //console.log(CountresultsDD);

        if(CountresultsDD!=undefined && CountresultsDD.length>0){
          for(let i in CountresultsDD){
              let item=CountresultsDD[i];
              if(item.Accelerator_x0020_Name.Accelerator =="Process Flows")
                  ProcessCount=ProcessCount+1;
              else if(item.Accelerator_x0020_Name.Accelerator =="Task Guides")
                  TaskGuide=TaskGuide+1;
              else if(item.Accelerator_x0020_Name.Accelerator =="Training Documents")
                  TraininDoc=TraininDoc+1;	            
          }  
        
     }
     this.industryHierachyDetails.push(new models.IndustryHierachy({industrySolutionName:"",shortDescription:"",longDescription:"",imageUrl:"",lomImageUrl:"",e2eImageUrl:"",countProcessFlow:ProcessCount, countTrainingDoc:TraininDoc,countTaskGuide:TaskGuide }));
     return this.industryHierachyDetails;
  }

}
