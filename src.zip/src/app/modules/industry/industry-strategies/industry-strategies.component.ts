import { Component, OnInit,Input } from '@angular/core';
import * as models from '../../../service/_models'; 
import { IndustryService } from '../../../service/_services/industry.service';

@Component({
  selector: 'app-industry-strategies',
  templateUrl: './industry-strategies.component.html',
  styleUrls: ['./industry-strategies.component.scss']
})
export class IndustryStrategiesComponent implements OnInit {

  public businessProcessGoalData : any;
  public businessProcessGoals: Array<models.BusinessPorcessGoals>;
  public businessProcessMetricsData : any;
  public businessProcessMetrics: Array<models.BusinessPorcessMetrics>;
  
  @Input() subSiteName:string;

  constructor(private _industryService : IndustryService) { }

  ngOnInit() {

          // Calling Goal Data
            this._industryService.GetGoalData(this.subSiteName).subscribe(y => {
                   this.businessProcessGoalData=y;

              if(this.businessProcessGoalData != null || this.businessProcessGoalData.lenght != undefined)
              {
                  this.businessProcessGoals=this.mapBusinessProcessGoals();
                  this._industryService.businessProcessGoalData = this.businessProcessGoals;
                  
              }

            });   

          // Calling Metrics Data
            this._industryService.GetMetricsData(this.subSiteName).subscribe(y => {
                   this.businessProcessMetricsData=y;

              if(this.businessProcessMetricsData != null || this.businessProcessMetricsData.lenght != undefined)
              {
                  this.businessProcessMetrics=this.mapBusinessProcessMetrics();
                  this._industryService.businessProcessMetricsData = this.businessProcessMetrics;
                  
              }

            });  

  }
public mapBusinessProcessMetrics() : Array<models.BusinessPorcessMetrics> 
  {
        let resultsDD=this.businessProcessMetricsData.d.results;
        if(resultsDD!=undefined && resultsDD.length>0){
            for(let i in resultsDD){    
                let item=resultsDD[i];                
                this.businessProcessMetrics.push({metricName:item.Metric_x0020_Name,goalName:item.Goal.Goal_x0020_Name,objective:item.Objective,notes:item.Notes1,Id:item.ID});    
            }                       
        }
        return this.businessProcessMetrics;
  }

public mapBusinessProcessGoals() : Array<models.BusinessPorcessGoals> 
  {
        let resultsDD=this.businessProcessGoalData.d.results;
  
        if(resultsDD!=undefined && resultsDD.length>0){
            for(let i in resultsDD)
            {    
                let item=resultsDD[i];                
                this.businessProcessGoals.push({goalName:item.Goal_x0020_Name,importance:item.Importance,notes:item.Notes1,Id:item.ID});    
            }                       
        }
        return this.businessProcessGoals;
  }
}
