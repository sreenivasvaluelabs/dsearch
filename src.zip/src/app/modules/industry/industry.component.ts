import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as models from '../../service/_models'; 
import { IndustryService } from '../../service/_services/industry.service';

@Component({
  selector: 'app-industry',
  templateUrl: './industry.component.html',
  styleUrls: ['./industry.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class IndustryComponent implements OnInit {
  
  subSiteName : string;
  public overviewdata:any;

  public industryOverviewTitle: String;
  public industryOverviewDesc: String;
  public businessOverviewTitle: String;
  public businessOverviewDesc: String;

  public businessProcessTitle: String;
  public businessProcessDesc: String;

  public industryIsAlternateRow: boolean;
  public isIndustryDataFound: boolean;

  industryListTab: any = [];
  industryOverviewDetails: any;
  industryDetailoverview : any =[];
  public industryHierachyDetails: Array<models.IndustryHierachy>;
  public businessPorcessItems: Array<models.BusinessPorcessItems>;
  public businessProcessDetailData : Array<models.BusinessProcessDetail>;

  clickedTab: any;

  lomViewURL: string;
  e2eViewURL: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private _industryService : IndustryService) {

      this.industryHierachyDetails = new Array<models.IndustryHierachy>();

      this.clickedTab ="Overview";
      this.isIndustryDataFound=false;

      
   }

  ngOnInit() {

           this.route
                  .queryParams
                  .subscribe(params => {
        
              this.subSiteName = params['subSiteName'];

          //console.log("this.subSiteName main industry component");
         // console.log(this.subSiteName);
          });
      
          this._industryService.GetIndustryOverview(this.subSiteName).subscribe(x => {
          this.industryOverviewDetails = x;

          //console.log("this.industryOverviewDetails");
          //console.log(this.industryOverviewDetails);

          if(this.industryOverviewDetails != null || this.industryOverviewDetails.lenght != undefined)
          {
                //console.log(this.industryOverviewDetails);
                  //For sharepoint testing
                this.industryHierachyDetails = this.mapIndustryOverviewComponentData();
                //console.log(this.industryHierachyDetails);

              
                this.industryHierachyDetails.forEach((x:models.IndustryHierachy) => {
                      
                      this.industryOverviewTitle="Industry Overview";     
                      this.industryOverviewDesc=x.longDescription; 
                      
                      this.lomViewURL=x.lomImageUrl;
                      this.e2eViewURL=x.e2eImageUrl;

                      this.businessOverviewTitle ="Business Overview";
                      this.businessOverviewDesc ="";
            
                      this.businessProcessTitle = "Business Processes"
                      this.businessProcessDesc =""

                      this.industryListTab = [
                          { "name": "Overview" }, { "name": "Business Processes" },
                          { "name": "Buisness Strategies" }, { "name": "Accelerators" },
                          { "name": "Assets" }, { "name": "Contacts" }
                        ];
                  
                });
                this.isIndustryDataFound=true;
          }
          else{
            this.isIndustryDataFound=false;
          }

      });

      //For local testing
      //this.industryHierachyDetails=this.industryOverviewDetails;

    //this.industryOverviewDesc=this.industryHierachyDetails[0].longDescription;

  }
  
  tabChanged($event: any) {
    this.clickedTab = $event;
  }

 private mapIndustryOverviewComponentData(): Array<models.IndustryHierachy> {
    
        let ProcessCount=0;
        let TraininDoc=0;
        let TaskGuide=0;

       // console.log("Industry Component");
       // console.log(this.industryOverviewDetails);

        //let resultsDD = this.industryOverviewDetails.d.results;
        let resultsDD = this.industryOverviewDetails.value;
         
          if(resultsDD!=undefined && resultsDD.length>0){
            
                 for(let i in resultsDD){
                     let item=resultsDD[i];
                     //let metadata=item.Industry_x0020_Solution.results;
                     let metadata=item.Industry_x0020_Solution;   
                     let level=metadata[0].Label;
                     level=level.split(":");						
                     let IndustrySolution=level[2];
                     let imageURL="";
                     let LOM="";
                     let E2E="";
                     if(item.Image_x0020_URL !=null )
                         imageURL=item.Image_x0020_URL["Description"];	
                     if(item.LOM_x0020_Image_x0020_URL !=null )
                         LOM=item.LOM_x0020_Image_x0020_URL["Description"];	
                     if(item.E2E_x0020_Image_x0020_URL !=null )
                         E2E=item.E2E_x0020_Image_x0020_URL["Description"];						
                         this.industryDetailoverview.push({industrySolutionName:IndustrySolution,shortDescription:item.Short_x0020_Description,longDescription:item.Long_x0020_Description,imageUrl:imageURL,lomImageUrl: LOM,e2eImageUrl:E2E });					
                 }
            }
           
         this.industryHierachyDetails.push(new models.IndustryHierachy({industrySolutionName:this.industryDetailoverview[0].industrySolutionName,shortDescription:this.industryDetailoverview[0].shortDescription,longDescription:this.industryDetailoverview[0].longDescription,imageUrl:this.industryDetailoverview[0].imageUrl,lomImageUrl:this.industryDetailoverview[0].lomImageUrl,e2eImageUrl:this.industryDetailoverview[0].e2eImageUrl,countProcessFlow:ProcessCount, countTrainingDoc:TraininDoc,countTaskGuide:TaskGuide }));
         return this.industryHierachyDetails;
      }

}
