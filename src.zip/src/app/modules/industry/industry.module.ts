import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';  //<<<< import it here
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { IndustryService } from '../../service/_services/industry.service';
import { PagerService } from '../../service/_services/pager.service';
import { SharedModule } from '../../shared/shared.module';
import { IndustryComponent } from './industry.component';

import { BusinessDetailComponent } from './business-detail/business-detail.component';
import { BusinessDetailHeaderComponent } from './business-detail-header/business-detail-header.component';
import { BusinessDetailTilesComponent } from './business-detail-tiles/business-detail-tiles.component';
import { BusinessDetailTreenavComponent } from './business-detail-treenav/business-detail-treenav.component';
import { BusinessOverviewComponent } from './business-overview/business-overview.component';
import { BusinessProcessComponent } from './business-process/business-process.component';
import { BusinessStaggeredviewComponent } from './business-staggeredview/business-staggeredview.component';
import { BusinessTableviewComponent } from './business-tableview/business-tableview.component';
import { IndustrybannerComponent } from './industry-banner/industrybanner.component';
import { IndustryOverviewComponent } from './industry-overview/industry-overview.component';
import { IndustryStrategiesComponent } from './industry-strategies/industry-strategies.component';
import { IndustryAcceleratorsComponent } from './industry-accelerators/industry-accelerators.component';
import { IndustryAssetsComponent } from './industry-assets/industry-assets.component';
import { IndustryContactsComponent } from './industry-contacts/industry-contacts.component';

 
@NgModule({
  imports: [
    CommonModule,
    SharedModule,NgbModule,FormsModule
  ],
  declarations: [
    IndustrybannerComponent,
    IndustryOverviewComponent,
    IndustryComponent,
    BusinessOverviewComponent,
    BusinessProcessComponent,
    BusinessTableviewComponent,
    BusinessStaggeredviewComponent,
    BusinessDetailComponent,
    BusinessDetailHeaderComponent,
    BusinessDetailTreenavComponent,
    BusinessDetailTilesComponent,
    IndustryStrategiesComponent,
    IndustryAcceleratorsComponent,
    IndustryAssetsComponent,
    IndustryContactsComponent
    
    ],
  exports: [
    IndustrybannerComponent,
    IndustryOverviewComponent
  ],
    providers: [IndustryService,PagerService]
})
export class IndustryModule { }
