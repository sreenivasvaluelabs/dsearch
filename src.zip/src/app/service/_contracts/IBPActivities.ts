export interface IBusinessProcessActivities{
    Id:string;
    application:string;
    lane:string;
    recordingType:string;
    activityType:string;
    activityName:string;
    businessProcessLevelId: string;
}