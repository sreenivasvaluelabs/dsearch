export interface IBPAssets{
    assetId:string;
    assetName:string;
    phase:string;
    accelerator:string;
    description:string;
    businessProcessLevelId: string; 
    previewSrc:string;
    imageIcon: string;
}