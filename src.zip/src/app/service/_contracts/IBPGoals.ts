export interface IBusinessProcessGoals{
    Id: string;
    goalName: string;
    importance: string;
    notes: string;
  
}