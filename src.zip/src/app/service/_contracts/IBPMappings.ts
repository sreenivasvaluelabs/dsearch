export interface IBusinessProcessMappings{
    Id: string;
    notes: string;
     businessProcessLevelId: string;
    goalName: string;
    metricsName: string;
}