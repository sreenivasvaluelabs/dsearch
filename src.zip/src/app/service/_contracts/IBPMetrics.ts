export interface IBusinessProcessMetrics{
    Id: string;
    metricName: string;
    objective: string;
    notes:string;
    goalName: string;
}
