export interface IBusinessProcessPreview{
  businessProcessLevelid: string;
  previewSrc:string;
}
