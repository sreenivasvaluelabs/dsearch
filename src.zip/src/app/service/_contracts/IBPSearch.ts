export interface IBPSearch{
    levelid: string;  //level1
    itemname: string;
    parentid  : string;
    children: Array<IBPSearch>;
}
