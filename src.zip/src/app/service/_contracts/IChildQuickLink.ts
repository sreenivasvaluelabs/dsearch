export interface IChildQuickLink{
    quickLinkID : number;
    quickLinkName : string;
    url : string;
}