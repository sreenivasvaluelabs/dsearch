export interface IContacts{
    displayName : String;
    email : string;
    region : string;
    role : string;
    imageUrl : string;
}