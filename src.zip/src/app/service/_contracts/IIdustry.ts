
import {IIndustrysubGroup} from './IIndustrySubgroup';

export interface IIndustryGroup {
    industryGroupName: string;
    industrySubGroup: Array<IIndustrysubGroup>;
    industryCount:number;
}

