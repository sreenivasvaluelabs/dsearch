export interface IIndustryAccelerator{
    accelatorName: string;
    phase: string;
    imageUrl: string;
}