
import {IIndustryDetail} from './IIndustryDetail';

export interface IIndustrysubGroup {
    subIndustryGroupName: string;
    industries: Array<IIndustryDetail>;
}

