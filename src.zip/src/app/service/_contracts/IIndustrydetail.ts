export interface IIndustryDetail{
    industyDetailId: string;
    imageUrl: string;
    industryName: string;
    subSiteName: string;
   
}