export interface ILearningBoard{
    learningBoard : String;
    learningBoardType : string;
    learningBoardLevel : string;
}