export interface ILogicalOpeModel{
    Id: string;
    itemName: string;
    imageUrl: string;
    description: string;
    detailUrl: string;

}