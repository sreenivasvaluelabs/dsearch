// export interface IOtherResource{
//     title: string; 
//     imageUrl: string;
//     description: string;
// }

export interface IOtherResource{
    menu : string;
    parentMenu : string;
    level : number;
    url : string;
    imageUrl : string;
    description : string;
    linkType : string;
}