export interface ITab{
    name : string;
    count:number;
}