export interface ITileItem{
    title : string;
    subTitle : string;
    imageUrl : string;
    description : string;
    tileType : string;
}