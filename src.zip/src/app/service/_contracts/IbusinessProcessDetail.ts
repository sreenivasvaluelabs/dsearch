export interface IbusinessProcessDetail{
    processID:string;
    name:string;
    type:string;
    area:string;
    status:string;
    owner:string;
    scoping:string;
    description:string;
    businessProcessLevelId: string;
    businessProcessname: string;
}
