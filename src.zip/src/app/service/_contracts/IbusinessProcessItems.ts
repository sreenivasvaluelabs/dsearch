export interface IBusinessProcessItem {
    levelid: string;  //level1
    itemname: string;
    parentid  : string;
}
