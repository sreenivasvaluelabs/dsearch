export interface Iindustryhierachy{
    industrySolutionName: string;
    shortDescription: string;
    longDescription: string;
    imageUrl: string;
    lomImageUrl: string;
    e2eImageUrl: string;
    countProcessFlow: number;
    countTrainingDoc: number;
    countTaskGuide: number;
}