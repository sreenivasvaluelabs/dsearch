import {IIndustryGroup} from './IIdustry';

export interface ILeaderShipRoles{
    displayName : String;
    email : string;
    region : string;
    role: string;
    imageUrl: string;
    industryOwner: Array<IIndustryGroup>;
}
