
import {ISubMenu} from './Isubmenu';

export interface INavigation{
    menuId: string;
    menuName: string;
    submenuDetails: Array<ISubMenu>;
}