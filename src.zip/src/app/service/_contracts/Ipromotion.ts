export interface IPromotion{
    promotionId: string;
    promotionName: string;
    imageUrl: string;      
    description: string;
    knowMoreUrl: string; 
    knowMoreText: string;
}