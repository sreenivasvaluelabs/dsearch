import {IChildQuickLink} from './IChildQuickLink';

export interface IQuickLinks{
    parentQuickLinkName : string;
    childQuickLinks : Array<IChildQuickLink>
}