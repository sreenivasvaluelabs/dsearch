
export interface ISubMenu{
    submenuId: string;
    menuName: string;
  
}