export interface IToolsAccelerator{
    Id: string;
    accelatorName: string;
    imageUrl: string;
}