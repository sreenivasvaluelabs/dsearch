import * as contracts from '../_contracts';

export class BusinessPorcessAccelerator implements contracts.IBusinessProcessAcc {
        assetId:string;
        assetName:string;
        phase:string;
        accelerator:string;
        description:string;
        businessProcessLevelId: string;
        previewSrc:string;
        imageIcon: string;

    constructor(bpAcce?: contracts.IBusinessProcessAcc){
        this.assetId =bpAcce.assetId;
        this.assetName =bpAcce.assetName;
        this.phase =bpAcce.phase;
        this.accelerator =bpAcce.accelerator;
        this.description =bpAcce.description;
        this.businessProcessLevelId=bpAcce.businessProcessLevelId; 
        this.previewSrc = bpAcce.previewSrc;
        this.imageIcon = bpAcce.imageIcon;
    } 
}