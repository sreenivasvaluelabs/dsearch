import * as contracts from '../_contracts';

export class BusinessProcessActivities implements contracts.IBusinessProcessActivities {
    Id:string;
    application:string;
    lane:string;
    recordingType:string;
    activityType:string;
    activityName:string;
    businessProcessLevelId: string;

    constructor(bpActivities?: contracts.IBusinessProcessActivities){
        this.Id = bpActivities.Id;
        this.application = bpActivities.application;
        this.lane = bpActivities.lane;
        this.recordingType = bpActivities.recordingType;
        this.activityType = bpActivities.activityType;
        this.activityName = bpActivities.activityName;
        this.businessProcessLevelId=bpActivities.businessProcessLevelId; 
    }
}