import * as contracts from '../_contracts';

export class BusinessProcessAssets implements contracts.IBPAssets {

    assetId:string;
    assetName:string;
    phase:string;
    accelerator:string;
    description:string;
    businessProcessLevelId: string;
    previewSrc:string;
    imageIcon: string;

    constructor(bpAssets?: contracts.IBPAssets){
        this.assetId = bpAssets.assetId;
        this.assetName = bpAssets.assetName;
        this.phase = bpAssets.phase;
        this.accelerator = bpAssets.accelerator;
        this.description = bpAssets.description;
        this.businessProcessLevelId=bpAssets.businessProcessLevelId; 
        this.previewSrc = bpAssets.previewSrc;
        this.imageIcon = bpAssets.imageIcon;
    } 
}
