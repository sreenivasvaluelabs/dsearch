import * as contracts from '../_contracts';

export class BusinessPorcessGoals implements contracts.IBusinessProcessGoals {
        Id: string;
        goalName: string;
        importance: string;
        notes: string;
       

    constructor(busiProGoals?: contracts.IBusinessProcessGoals){
        this.Id = busiProGoals.Id;
        this.goalName = busiProGoals.goalName;
        this.importance = busiProGoals.importance;
        this.notes = busiProGoals.notes;
        
    }
}