import * as contracts from '../_contracts';

export class BusinessPorcessMapping implements contracts.IBusinessProcessMappings {
    Id: string;
    notes: string;
    businessProcessLevelId: string;
    businessProcessLevelname: string;
    goalName: string;
    metricsName: string;

    constructor(busiProMapping?: contracts.IBusinessProcessMappings){
        this.Id = busiProMapping.Id;
        this.notes = busiProMapping.notes;
        this.businessProcessLevelId = busiProMapping.businessProcessLevelId;
        this.goalName= busiProMapping.goalName;
        this.metricsName= busiProMapping.metricsName;
    }
}