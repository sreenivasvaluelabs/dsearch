import * as contracts from '../_contracts';

export class BusinessPorcessMetrics implements contracts.IBusinessProcessMetrics {
            Id: string;
            metricName: string;
            objective: string;
            notes:string;
            goalName: string;

    constructor(busiProMetrics?: contracts.IBusinessProcessMetrics){
        this.Id = busiProMetrics.Id;
        this.metricName = busiProMetrics.metricName;
        this.objective = busiProMetrics.objective;
        this.notes = busiProMetrics.notes;
        this.goalName = busiProMetrics.goalName;
    }
}