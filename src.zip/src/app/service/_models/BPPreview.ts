import * as contracts from '../_contracts';

export class BusinessPorcessPreview implements contracts.IBusinessProcessPreview {
        businessProcessLevelid: string;
        previewSrc:string;
       

    constructor(busiPropreview?: contracts.IBusinessProcessPreview){
        this.businessProcessLevelid = busiPropreview.businessProcessLevelid;
        this.previewSrc = busiPropreview.previewSrc;
       
        
    }
}