
import * as contracts from '../_contracts';

export class BPSearch implements contracts.IBPSearch {
    levelid: string;  //level1
    itemname: string;
    parentid  : string;
    children: Array<contracts.IBPSearch>;

    constructor(busiSearchitems?: contracts.IBPSearch){
        this.levelid = busiSearchitems.levelid;
        this.itemname = busiSearchitems.itemname;
        this.parentid = busiSearchitems.parentid;
        this.children= busiSearchitems.children;
    }
}