import * as contracts from '../_contracts';

export class BusinessPorcessItems implements contracts.IBusinessProcessItem {
        levelid: string;  //level1
        itemname: string;
        parentid  : string;

    constructor(busiProditems?: contracts.IBusinessProcessItem){
        this.levelid = busiProditems.levelid;
        this.itemname = busiProditems.itemname;
        this.parentid = busiProditems.parentid;
    }
}