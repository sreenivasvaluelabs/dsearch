import * as contracts from '../_contracts';

export class industryGroup implements contracts.IIndustryGroup {
    industryGroupName: string;
    industrySubGroup: Array<contracts.IIndustrysubGroup>;
    industryCount:number;

    constructor(industry?: contracts.IIndustryGroup){

        this.industryGroupName = industry.industryGroupName;
        //for each industry
        this.industrySubGroup = industry.industrySubGroup;
        this.industryCount = industry.industryCount;
    }
}