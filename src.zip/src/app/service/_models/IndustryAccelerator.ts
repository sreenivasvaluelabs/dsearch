import * as contracts from '../_contracts';

export class IndustryAccelerator implements contracts.IIndustryAccelerator {
        accelatorName: string;
        phase: string;
        imageUrl: string;

    constructor(industryAcc?: contracts.IIndustryAccelerator){

        this.accelatorName = industryAcc.accelatorName;
        this.phase = industryAcc.phase;
        this.imageUrl = industryAcc.imageUrl;
       
    }
}