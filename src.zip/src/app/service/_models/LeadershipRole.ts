import * as contracts from '../_contracts';

export class LeaderShipRoles implements contracts.ILeaderShipRoles {
        displayName : String;
        email : string;
        region : string;
        role: string;
        imageUrl: string;
        industryOwner: Array<contracts.IIndustryGroup>;
        
    constructor(leadership?: contracts.ILeaderShipRoles){
        this.displayName =leadership.displayName;
        this.email =leadership.email;
        this.region=leadership.region;
        this.role=leadership.role;
        this.imageUrl=leadership.imageUrl;
        this.industryOwner=leadership.industryOwner;
    } 
}