import * as contracts from '../_contracts';

export class LearningBoard implements contracts.ILearningBoard {
    learningBoard : String;
    learningBoardType : string;
    learningBoardLevel : string;
        
    constructor(learningBoard?: contracts.ILearningBoard){
        this.learningBoard =learningBoard.learningBoard;
        this.learningBoardType =learningBoard.learningBoardType;
        this.learningBoardLevel=learningBoard.learningBoardLevel;
    } 
}