import * as contracts from '../_contracts';

export class OtherResource implements contracts.IOtherResource{
    // title: string; 
    // imageUrl: string;
    // description: string;

    // constructor(otherResource?: contracts.IOtherResource){
    //     this.title = otherResource.title;
    //     this.description = otherResource.description;
    //     this.imageUrl = otherResource.imageUrl;
    // }

    menu : string;
    parentMenu : string;
    level : number;
    url : string;
    imageUrl : string;
    description : string;
    linkType : string;

    constructor(otherResource?: contracts.IOtherResource){
        this.menu = otherResource.menu;
        this.parentMenu = otherResource.parentMenu;
        this.level = otherResource.level;
        this.imageUrl = otherResource.imageUrl;
        this.description = otherResource.description;
        this.linkType = otherResource.linkType;
    }
}