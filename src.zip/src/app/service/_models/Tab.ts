import * as contracts from '../_contracts';

export class Tab implements contracts.ITab{
    name : string;
    count:number;

    constructor(tab : contracts.ITab){
        this.name = tab.name;
        this.count = tab.count;
    }
}