import * as contracts from '../_contracts';

export class TileItem implements contracts.ITileItem{
    title : string;
    subTitle : string;
    imageUrl : string;
    description : string;
    tileType : string;

    constructor(tileItem : contracts.ITileItem){
        this.title = tileItem.title;
        this.subTitle = tileItem.subTitle;
        this.imageUrl = tileItem.imageUrl;
        this.description = tileItem.description;
        this.tileType = tileItem.tileType;
    }
}