import * as contracts from '../_contracts';

export class BusinessProcessDetail implements contracts.IbusinessProcessDetail {
        processID:string;
        name:string;
        type:string;
        area:string;
        status:string;
        owner:string;
        scoping:string;
        description:string;
        businessProcessLevelId: string;
        businessProcessname: string;

    constructor(busiProdetail?: contracts.IbusinessProcessDetail){
        this.processID = busiProdetail.processID;
        this.name = busiProdetail.name;
        this.type = busiProdetail.type;
        this.area = busiProdetail.area;
        this.status = busiProdetail.status;
        this.owner = busiProdetail.owner;
        this.scoping = busiProdetail.scoping;
        this.description = busiProdetail.description;
        this.businessProcessLevelId = busiProdetail.businessProcessLevelId;
        this.businessProcessname = busiProdetail.businessProcessname;
    }
}