import * as contracts from '../_contracts';

export class ChildQuickLink implements contracts.IChildQuickLink {
    quickLinkID : number;
    quickLinkName : string;
    url : string;

    constructor(childQuickLinks?: contracts.IChildQuickLink){
        this.quickLinkID = childQuickLinks.quickLinkID;
        this.quickLinkName = childQuickLinks.quickLinkName;
        this.url = childQuickLinks.url;
    }
}