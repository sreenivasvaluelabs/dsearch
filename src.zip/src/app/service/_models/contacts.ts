import * as contracts from '../_contracts';

export class Contacts implements contracts.IContacts {
    displayName : String;
    email : string;
    region : string;
    role : string;
    imageUrl : string;

    constructor(contacts?: contracts.IContacts){
        this.displayName = contacts.displayName;
        this.email = contacts.email;
        this.region = contacts.region;
        this.role = contacts.role;
        this.imageUrl = contacts.imageUrl;
    }
}