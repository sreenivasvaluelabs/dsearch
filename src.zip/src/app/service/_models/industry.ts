import * as contracts from '../_contracts';

export class IndustryDetail implements contracts.IIndustryDetail {
        industyDetailId: string;
        imageUrl: string;
        industryName: string;
        subSiteName: string

    constructor(industry?: contracts.IIndustryDetail){

        this.industyDetailId = industry.industyDetailId;
        this.imageUrl = industry.imageUrl;
        this.industryName = industry.industryName;
        this.subSiteName = industry.subSiteName;
    }
}