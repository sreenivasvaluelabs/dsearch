import * as contracts from '../_contracts';

export class IndustryHierachy implements contracts.Iindustryhierachy {
        industrySolutionName: string;
        shortDescription: string;
        longDescription: string;
        imageUrl: string;
        lomImageUrl: string;
        e2eImageUrl: string;
        countProcessFlow: number;
        countTrainingDoc: number;
        countTaskGuide: number;

    constructor(industry?: contracts.Iindustryhierachy){

        this.industrySolutionName = industry.industrySolutionName;
        this.shortDescription = industry.shortDescription;
        this.longDescription = industry.longDescription;
        this.imageUrl = industry.imageUrl;
        this.lomImageUrl = industry.lomImageUrl;
        this.e2eImageUrl = industry.e2eImageUrl;
        this.countProcessFlow = industry.countProcessFlow;
        this.countTrainingDoc = industry.countTrainingDoc;
        this.countTaskGuide = industry.countTaskGuide;
    }
}