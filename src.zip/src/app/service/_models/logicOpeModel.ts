import * as contracts from '../_contracts';

export class LogicOpeModel implements contracts.ILogicalOpeModel {
        Id: string;
        itemName: string;
        imageUrl: string;
        description: string;
        detailUrl: string
   

    constructor(logicopemodel?: contracts.ILogicalOpeModel){
        if (logicopemodel) {
            this.Id = logicopemodel.Id;
            this.itemName = logicopemodel.itemName;
            this.imageUrl = logicopemodel.imageUrl;
            this.description = logicopemodel.description;
            this.detailUrl = logicopemodel.detailUrl;
        }
    }
}