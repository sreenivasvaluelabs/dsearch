import * as contracts from '../_contracts';

export class Promotion implements contracts.IPromotion {
    promotionId: string;
    promotionName: string;
    imageUrl: string;
    description: string;
    knowMoreUrl: string;
    knowMoreText: string;

    constructor(promotion?: contracts.IPromotion){
        if (promotion) {
            this.promotionId = promotion.promotionId;
            this.promotionName = promotion.promotionName;
            this.imageUrl = promotion.imageUrl;
            this.description = promotion.description;
            this.knowMoreUrl = promotion.knowMoreUrl;
            this.knowMoreText = promotion.knowMoreText;
        }
    }
}