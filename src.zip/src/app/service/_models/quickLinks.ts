import * as contracts from '../_contracts';

export class QuickLinks implements contracts.IQuickLinks {
    parentQuickLinkName : string;
    childQuickLinks : Array<contracts.IChildQuickLink>
   

    constructor(quicklinks?: contracts.IQuickLinks){
        if (quicklinks) {
            this.parentQuickLinkName = quicklinks.parentQuickLinkName;
            this.childQuickLinks = quicklinks.childQuickLinks;
        }
    }
}