import * as contracts from '../_contracts';

export class SubindustryGroup implements contracts.IIndustrysubGroup {
    subIndustryGroupName: string;
    industries: Array<contracts.IIndustryDetail>;

    constructor(industry?: contracts.IIndustrysubGroup){

        this.subIndustryGroupName = industry.subIndustryGroupName;
        //for each industry
        this.industries = industry.industries
    }
}