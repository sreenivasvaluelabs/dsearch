import * as contracts from '../_contracts';

export class ToolsAccelerator implements contracts.IToolsAccelerator {
    Id: string;
    accelatorName: string;
    imageUrl: string;
 

    constructor(toolsAcc?: contracts.IToolsAccelerator){
        if (toolsAcc) {
            this.Id = toolsAcc.Id;
            this.accelatorName = toolsAcc.accelatorName;
            this.imageUrl = toolsAcc.imageUrl;
        }
    }
}