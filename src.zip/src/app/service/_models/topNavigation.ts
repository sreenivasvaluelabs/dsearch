import * as contracts from '../_contracts';

export class TopNavigation implements contracts.INavigation {
    menuId: string;
    menuName: string;
    submenuDetails: Array<contracts.ISubMenu>;
   

    constructor(topMenu?: contracts.INavigation){
        if (topMenu) {
            this.menuId = topMenu.menuId;
            this.menuName = topMenu.menuName;
            this.submenuDetails = topMenu.submenuDetails;
 
        }
    }
}