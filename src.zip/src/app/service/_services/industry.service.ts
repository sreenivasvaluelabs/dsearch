import { Injectable } from '@angular/core';
import * as models from '../_models'; 
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { Http, Headers, Response, RequestOptions} from '@angular/http';


declare var myExtObject: any;

@Injectable()
export class IndustryService {
 

private headers: Headers;

industryOverviewDetails : any=[];
industryCountDetails : any=[];
businessProcessResults : any=[];
BusinessProcessData : Array<models.BusinessPorcessItems>;
BusinessProcessDetailData : Array<models.BusinessProcessDetail>;

//Variable to hold data from API
public businessStrategyDetailsData : Array<models.BusinessPorcessMapping>;
public assestDetailsData : Array<models.BusinessProcessAssets>;
public accelaratorDetailsData :  Array<models.BusinessPorcessAccelerator>;
public activitiesDetailsData : Array<models.BusinessProcessActivities>;
public businessProcessDetailsData : Array<models.BusinessProcessDetail>;
public businessProcessGoalData : Array<models.BusinessPorcessGoals>;
public businessProcessMetricsData : Array<models.BusinessPorcessMetrics>;
public industryContactsData : Array<models.Contacts>;
public businessPorcessItemsData: Array<any>;

  constructor(private http_: Http) { 

    this.businessStrategyDetailsData = new Array<models.BusinessPorcessMapping>();
    this.assestDetailsData = new Array<models.BusinessProcessAssets>();
    this.accelaratorDetailsData = new  Array<models.BusinessPorcessAccelerator>();
    this.activitiesDetailsData = new Array<models.BusinessProcessActivities>();
    this.businessProcessDetailsData = new Array<models.BusinessProcessDetail>();

    this.businessStrategyDetailsData = new  Array<models.BusinessPorcessMapping>();
    this.assestDetailsData = new  Array<models.BusinessProcessAssets>();
    this.accelaratorDetailsData = new   Array<models.BusinessPorcessAccelerator>();
    this.activitiesDetailsData = new  Array<models.BusinessProcessActivities>();
    this.businessProcessDetailsData = new  Array<models.BusinessProcessDetail>();
    this.businessProcessGoalData = new  Array<models.BusinessPorcessGoals>();
    this.businessProcessMetricsData = new  Array<models.BusinessPorcessMetrics>();
    this.industryContactsData = new  Array<models.Contacts>(); 
    this.businessPorcessItemsData = new Array<any>();
  }


 private getHeaders() {
    try {
        var headers = new Headers();
        var digest = document.getElementById("__REQUESTDIGEST") as HTMLInputElement;
        headers.set('Accept', 'application/json;odata=verbose');
        headers.set('Content-Type', 'application/json;odata=verbose');
        headers.set('X-RequestDigest', digest.value);
        headers.set('X-HTTP-Method', 'POST');
        headers.set('Access-Control-Allow-Headers', 'Content-Type');
        
        return headers;
    }
    catch (e) {
        console.log(e)
    }
}

 public GetIndustryOverview(subSiteName:string):Observable<Array<models.IndustryHierachy>>{ // added by lakshmi for Industry Detail overview

// SharePoint API Call
    let industryUrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Industry%20Hierarchy')/items"; // Retails name should by dynamic
    return this.http_.get(industryUrl + "?$select=E2E_x0020_Image_x0020_URL,LOM_x0020_Image_x0020_URL,Image_x0020_URL,Industry_x0020_Solution,Long_x0020_Description,Short_x0020_Description", {headers: this.getHeaders()}).map(response=>response.json());

 }
 public GetIndustryCount(subSiteName:string):Observable<Array<models.IndustryHierachy>>{

// SharePoint API Call
   let industryCountUrl ="/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Assets')/items";
   return this.http_.get(industryCountUrl + "?$select=Accelerator_x0020_Name/Accelerator&$expand=Accelerator_x0020_Name", {headers: this.getHeaders()}).map(response=>response.json());

}
  
public GetBusinessProcessDetailData(subSiteName:string):Observable<Array<models.BusinessProcessDetail>>{ // added by lakshmi for Industry Detail overview
   
        // SharePoint API Call
        let BusinesUsrl = "/sites/AIES/"+ subSiteName +"/_api/web/lists/getbytitle('Business%20Process%20Hierarchy')/items"; // Retails name should by dynamic
        return this.http_.get(BusinesUsrl + "?$select=Owner/UserName,Owner/Title,*&$expand=Owner", {headers: this.getHeaders()}).map(response=>response.json());
    
     }

public getAssestAccelaratorcode(subSiteName:string):Observable<Array<models.BusinessProcessAssets>>{ // added by lakshmi for Industry Detail overview
    
     // SharePoint API Call
     let assetsUsrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Assets')/items"; // Retails name should by dynamic
     return this.http_.get(assetsUsrl + "?$select=FieldValuesAsText/FileRef,FieldValuesAsText/FileLeafRef,File/Name,Accelerator_x0020_Name/Accelerator,*&$expand=FieldValuesAsText,Accelerator_x0020_Name,File", {headers: this.getHeaders()}).map(response=>response.json());
}

public GetStratagyOverview(subSiteName:string):Observable<Array<models.BusinessPorcessMapping>>{ 
     
     // SharePoint API Call
         let mappingUsrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Mapping')/items"; // Retails name should by dynamic
         return this.http_.get(mappingUsrl + "?$select=Goal/Goal_x0020_Name,Metric/Metric_x0020_Name,Notes1,Business_x0020_Process_x0020_Hie,ID&$expand=Goal,Metric", {headers: this.getHeaders()}).map(response=>response.json());
         //return this.http_.get(mappingUsrl + "?$select=Goal/Title,Metric/Title,Notes1,Business_x0020_Process_x0020_Hie,ID&$expand=Goal,Metric", {headers: this.getHeaders()}).map(response=>response.json());
 }    
public GetBusinessProcessActivites(subSiteName:string):Observable<Array<models.BusinessProcessActivities>>{ 
    // SharePoint API Call
    let activitiesUrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Activities')/items"; // Retails name should by dynamic
   return this.http_.get(activitiesUrl + "?select=*", {headers: this.getHeaders()}).map(response=>response.json());
}    

public GetBusinessProcessData(subSiteName:string):Observable<any>{
    
    // Call Javascript function get the data from sharepoint 
    return Observable.of(myExtObject.getBusinessProcessDataAll(subSiteName)).map((res:Response)=>res.json());           
           
 }
public GetGoalData(subSiteName:string):Observable<Array<models.BusinessPorcessGoals>>{ 
     
     // SharePoint API Call
    let goalUrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Goals')/items"; // Retails name should by dynamic
    return this.http_.get(goalUrl + "?select=*", {headers: this.getHeaders()}).map(response=>response.json());
 }   
 public GetMetricsData(subSiteName:string):Observable<Array<models.BusinessPorcessMetrics>>{ 
     
     // SharePoint API Call
    let metricsUrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Metrics')/items"; // Retails name should by dynamic
    return this.http_.get(metricsUrl + "?$select=Goal/Goal_x0020_Name,*&$expand=Goal", {headers: this.getHeaders()}).map(response=>response.json());
 }   
 public GetContactsData(subSiteName:string):Observable<Array<models.Contacts>>{ 
     
     // SharePoint API Call
        let ContactsUrl = "/sites/AIES/" + subSiteName + "/_api/web/lists/getbytitle('Contacts')/items"; // Retails name should by dynamic
        return this.http_.get(ContactsUrl + "?$select=Email/UserName,Email/EMail,*&$expand=Email", {headers: this.getHeaders()}).map(response=>response.json());
 }  
public GetBusinessprocessdatabyProcessLevel(processLevel:string,processTabType:string):Observable<Array<any>>{
    var filteredBusinessStrategyDetailsData = [];
    var filteredAssestDetailsData = [];
    var filteredAccelaratorDetailsData = [];
    var filteredActivitiesDetailsData = [];
    var filteredBusinessProcessDetailsData =[];

    switch(processTabType) { 
        case "strategy": { 
           console.log("strategy"); 

           filteredBusinessStrategyDetailsData = this.businessStrategyDetailsData.filter(function (el) {
            return (el.businessProcessLevelId === processLevel);
            });
           return Observable.of(filteredBusinessStrategyDetailsData);
        } 
        case "assest": { 
           console.log("assest"); 
           filteredAssestDetailsData = this.assestDetailsData.filter(function (el) {
            return (el.businessProcessLevelId === processLevel);
            });
           return Observable.of(filteredAssestDetailsData);
        } 
        case "accelarator": {
           console.log("accelarator");
           filteredAccelaratorDetailsData = this.accelaratorDetailsData.filter(function (el) {
            return (el.businessProcessLevelId === processLevel);
            });
           return Observable.of(filteredAccelaratorDetailsData);
        } 
        case "activities": { 
           console.log("activities"); 
           filteredActivitiesDetailsData = this.activitiesDetailsData.filter(function (el) {
            return (el.businessProcessLevelId === processLevel);
            });
           return Observable.of(filteredActivitiesDetailsData);
        }  
        default: { 
           console.log("BusinessProcessDetailData"); 
           filteredBusinessProcessDetailsData = this.businessProcessDetailsData.filter(function (el) {
            return (el.businessProcessLevelId === processLevel);
            });
           return Observable.of(filteredBusinessProcessDetailsData);        
        } 
     }
   // return Observable.of(this.industryOverviewDetails);
}

/*public GetBusinessprocessdatabyProcessLevel(processLevel:string,processTabType:string):Observable<Array<any>>{
    var filteredBusinessStrategyDetailsData = [];
    var filteredAssestDetailsData = [];
    var filteredAccelaratorDetailsData = [];
    var filteredActivitiesDetailsData = [];
    var filteredBusinessProcessDetailsData =[];

    switch(processTabType) { 
        case "strategy": { 
           for (var i = 0; i < this.businessStrategyDetailsData.length ; i++) {
               if (this.businessStrategyDetailsData[i].businessProcessLevelId === processLevel) {
                    filteredBusinessStrategyDetailsData.push(this.businessStrategyDetailsData[i]);
               }
           }
           return Observable.of(filteredBusinessStrategyDetailsData);
        } 
        case "assest": { 
           for (var i = 0; i < this.assestDetailsData.length ; i++) {
                if (this.assestDetailsData[i].businessProcessLevelId === processLevel) {
                    filteredAssestDetailsData.push(this.assestDetailsData[i]);
                }
        }
            return Observable.of(filteredAssestDetailsData);
        } 
        case "accelarator": {
           for (var i = 0; i < this.accelaratorDetailsData.length ; i++) {
            if (this.accelaratorDetailsData[i].businessProcessLevelId === processLevel) {
                filteredAccelaratorDetailsData.push(this.accelaratorDetailsData[i]);
            }
        }
            return Observable.of(filteredAccelaratorDetailsData);
        } 
        case "activities": { 
           for (var i = 0; i < this.activitiesDetailsData.length ; i++) {
            if (this.activitiesDetailsData[i].businessProcessLevelId === processLevel) {
                filteredActivitiesDetailsData.push(this.activitiesDetailsData[i]);
            }
        }
            return Observable.of(filteredActivitiesDetailsData);
        }  
        default: { 
           for (var i = 0; i < this.BusinessProcessDetailData.length ; i++) {
            if (this.BusinessProcessDetailData[i].businessProcessLevelId === processLevel) {
                filteredBusinessProcessDetailsData.push(this.BusinessProcessDetailData[i]);
            }
        }
            return Observable.of(filteredBusinessProcessDetailsData);            
        } 
     }
   // return Observable.of(this.industryOverviewDetails);
}*/

}