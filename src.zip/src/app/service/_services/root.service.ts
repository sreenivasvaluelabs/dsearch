import { Injectable } from '@angular/core';


import * as models from '../_models'; 
import { Http, Headers, Response,Request, RequestOptions, RequestMethod} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';

@Injectable()
export class RootService {

// for tools and accecelators
private tooAccdata: Array<models.ToolsAccelerator>;
private accelerators : Array<models.ToolsAccelerator>;

//for promotiondata
private slides : Array<models.Promotion>;

//For Other Resources or any other kind of links
private otherResources : Array<models.OtherResource>;
private otherResourcesData : Array<models.OtherResource>;
private quicklinksdata: Array<models.QuickLinks>;
private menudata: Array<models.TopNavigation>;
private quickLinks : Array<models.QuickLinks>;

public quickLinksMapped : Array<models.QuickLinks>;
public otherResourcesMapped : Array<models.OtherResource>;

headers: Headers;

private industryUrl: string = "/sites/AIES/_api/web/lists/getbytitle('Industry Hierarchy')/items";
private newPromotionUrl :string= "/sites/AIES/_api/web/lists/getbytitle('Promotions')/items"; // New Site URL for promotions
private newToolAccUrl: string= "/sites/AIES/_api/web/lists/getbytitle('Tools & Accelerators')/items"; // For Accelerators and tools
private LinksUrl: string= "/sites/AIES/_api/web/lists/getbytitle('Links')/items";


//new code
private tileList : any;
private tabList: any;

  constructor(private http_: Http) {

    this.otherResourcesMapped = new Array<models.OtherResource>();
    this.quickLinksMapped = new Array<models.QuickLinks>();
    this.otherResourcesData = new Array<models.OtherResource>();
    this.quicklinksdata = new Array<models.QuickLinks>();

    

   }
 
   private getHeaders() {
        try {

            
            var headers = new Headers();
            var digest = document.getElementById("__REQUESTDIGEST") as HTMLInputElement;
            headers.set('Accept', 'application/json;odata=verbose');
            headers.set('Content-Type', 'application/json;odata=verbose');
            headers.set('X-RequestDigest', digest.value);
            headers.set('X-HTTP-Method', 'POST');
            headers.set('Access-Control-Allow-Headers', 'Content-Type');
            return headers;
        }
        catch (e) {
            console.log(e)
        }
    }


//Get Industry Overview Data 
 public GetIndustryList() : Observable<Array<models.industryGroup>>{
   
    return this.http_.get(this.industryUrl + "?$select=Industry_x0020_Solution,ID,Subsite_x0020_name,Image_x0020_URL", { headers: this.getHeaders() }).map ((res: Response) => res.json())

  }
 
  public GetAllLinks() : Observable<Array<models.QuickLinks>>{

    if(this.quicklinksdata.length > 0)
        return  Observable.of(this.quicklinksdata);
    else
        return this.http_.get(this.LinksUrl + "?$select=Title,ID,Parent_x0020_Menu/Title,Level,URL,Link_x0020_Type,Image_x0020_URL,Ava_Description&$expand=Parent_x0020_Menu", {headers: this.getHeaders()}).map(response=>response.json());

  }

   public GetPromotionlist() : Observable<models.Promotion>{
    
        return this.http_.get(this.newPromotionUrl + "?$select=Title,ID,Image_x0020_URL,Know_x0020_More_x0020_Url,Ava_Description,Active", {headers: this.getHeaders()}).map(response=>response.json());
    }         
           
  public GetAccecelators() : Observable<Array<models.ToolsAccelerator>>{

        return this.http_.get(this.newToolAccUrl + "?$select=Accelerator,ID,Image_x0020_URL", {headers: this.getHeaders()}).map(response=>response.json());

  }

  public GetOtherResources() : Observable<Array<models.OtherResource>>{

       if(this.otherResourcesData.length > 0)
        return  Observable.of(this.otherResourcesData);
      else
        return this.http_.get(this.LinksUrl + "?$select=Title,ID,Parent_x0020_Menu/Title,Level,URL,Link_x0020_Type,Image_x0020_URL,Ava_Description&$expand=Parent_x0020_Menu", {headers: this.getHeaders()}).map(response=>response.json());
 
  }

}
