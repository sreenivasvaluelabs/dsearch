import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../core/auth/authentication.service';
import { I18nService } from '../../../core/i18/i18n.service';

@Component({
  selector: 'xd-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class CarouselComponent implements OnInit {

 @Input() interval: number;
 @Input() wrap: boolean;
 @Input() keyboard: boolean;

 @Input() slideSource: any;

  constructor(private router: Router,
              private authenticationService: AuthenticationService,
              private i18nService: I18nService) { }

  ngOnInit() {
    console.log("Value passed from component = "+this.interval);
    console.log("Value passed from component = "+JSON.stringify(this.slideSource));

   }

}
