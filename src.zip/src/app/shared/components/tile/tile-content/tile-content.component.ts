import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tile-content',
  templateUrl: './tile-content.component.html',
  styleUrls: ['./tile-content.component.scss']
})
export class TileContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
