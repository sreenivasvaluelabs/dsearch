export interface ListDataType {
    text: string; // Display text of the list
    value: any; // value number or string of the item
    enabled: boolean; // to disable/enable the list item
    selected: boolean; // to check if selected
    link: string; // for active list, this will be route
    badge: number; // to show number in a badge at end
    
}