import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XdListComponent } from './xd-list.component';

describe('XdListComponent', () => {
  let component: XdListComponent;
  let fixture: ComponentFixture<XdListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XdListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XdListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
