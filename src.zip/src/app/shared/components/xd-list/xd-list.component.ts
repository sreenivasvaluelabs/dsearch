import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Renderer } from '@angular/core';
import { ListDataType } from './listDataType';
import { SearchFilterPipe } from '../../../shared/pipes/filter.pipe';
import { IndustryService } from '../../../service/_services/industry.service';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { BusinessDetailHeaderComponent } from "../../../modules/industry/business-detail-header/business-detail-header.component"
import { Http } from '@angular/http';
import { BusinessDetailTilesComponent } from '../../../modules/industry/business-detail-tiles/business-detail-tiles.component';


@Component({
  selector: 'xd-list',
  templateUrl: './xd-list.component.html',
  styleUrls: ['./xd-list.component.scss']
})
export class XdListComponent implements OnInit {
  businessDetailHeader: BusinessDetailHeaderComponent;
  businessDetailTiles: BusinessDetailTilesComponent;
  selectedIndex: number;
  selectedIndices: number[] = [];
  searchText: any;
  @Input() listData: Array<ListDataType>; // data to create the list
  @Input() showBadges: boolean = false; // to show badge at the end
  @Input() selectable: string = "none"; // to make the list selectable - none | single | multiple

  @Output() listChange: EventEmitter<any> = new EventEmitter();

  constructor(private _industryService: IndustryService, private domSanitizer: DomSanitizer) {
    //this.businessDetailHeader = new BusinessDetailHeaderComponent(this._industryService);
    //this.businessDetailTiles = new BusinessDetailTilesComponent(this._industryService, this.domSanitizer);
  }
  ngOnInit() { }

  select(index: any) {
    //alert(index);
    //this.businessDetailHeader.businessDetailHeaderData(index);
    //this.businessDetailTiles.businessDetailTilesData(index);

  }

}
