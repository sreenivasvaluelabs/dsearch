
import { Component, Input, Output, Injectable, OnInit, AfterViewInit, EventEmitter,ViewEncapsulation } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { Pipe, PipeTransform } from '@angular/core';
import * as models from '../../../service/_models'; 

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


export class Searching {
    showTile: boolean;
    toIndex: number;
}
@Component({
    selector: 'xd-search',
    templateUrl: './xd-search.component.html',
    styleUrls: ['./xd-search.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class XDSearchComponent implements OnInit {
    private searcher: Searching;
    private listofSearchItems: Array<models.BPSearch>;

    filteredData: any;
    regex: any;
    transformData: any;
    newData: any;
    listData: any[];
    filteredListData: any[];
    test: any;
    test1: any;
    showTile: boolean;
    //@Input() data: any[];
    showSearch:boolean;
    showProcess:boolean;
    showNoResultsProcess:boolean;
    showEntire:boolean;
    showIcon:boolean;
    newformat:any[]
    //tree
    @Output() searching: EventEmitter<Searching> = new EventEmitter();
    constructor() {
        debugger;
        this.searcher = new Searching();
        this.listofSearchItems = new Array<models.BPSearch>();
        this.showTile = false;
        this.showSearch=false;
        this.showProcess=false;
        this.showNoResultsProcess=false;
        this.showEntire=false;
        this.showIcon=false;
        let BusinessProcessData=[];
        this.searcher.showTile=false;
    }
    ngOnInit() {
        debugger;
       // this.filteredListData.push({value: 'test1', text:'test11',badge:'0',enabled:'',selected:'',link:'' }); 
    }

    private sourceData: models.BPSearch[] = [];

    clicked(event:any) {
      
        debugger;
        this.filteredListData = [];
       this.test="";
      
       if(this.showSearch==false)
        {
            this.showTile = true;
            event.target.classList.add('fonticon-cancel'); // To ADD
            var pElement = event.target.parentElement;
            pElement.classList.add('searchbox-open');
            this.showSearch=true;
            this.showIcon=true;
            this.showProcess=true;
            this.searcher.showTile=true;
        }
        else{
            event.target.classList.remove('fonticon-cancel'); // To ADD
            var pElement = event.target.parentElement;
            pElement.classList.remove('searchbox-open');
            this.showSearch=false;
            this.showIcon=false;
            this.showProcess=false;
            this.showTile = false;
            this.searcher.showTile=false;
        }
        
        
        this.showNoResultsProcess=false;
        this.showEntire=false;
        this.searching.emit(this.searcher);
      }
      private computePager() {
       // this.searcher.showTile = true;
        //this.searcher.toIndex=0;

        //Time 1 to force number intead of string
      

    }
    valuechange(newValue: any) {

        debugger;
        this.showEntire=false;
        this.showProcess=false;
        this.test = newValue;
        this.filteredListData = [];
        if (newValue != "") {
            //this.filteredListData.push({value: 'test1', text:'test11',badge:'0',enabled:'',selected:'',link:'' }); 
            this.showTile = true;
            if( this.filteredListData.length>0)
                {
                    
                    this.showNoResultsProcess=false;
                }
                else{
                  
                    this.showNoResultsProcess=true;
                }
        }
        else {
            this.showTile = false;
        }
    }

}
