import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ViewEncapsulation } from '@angular/core';

import { IndustrySolutionsComponent } from '../../../modules/aieslanding-page/industry-solutions/industry-solutions.component';

@Component({
  selector: 'app-xd-section',
  templateUrl: './xd-section.component.html',
  styleUrls: ['./xd-section.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class XdSectionComponent implements OnInit {

@ViewChild(IndustrySolutionsComponent)
    private industrySolutionsComponent: IndustrySolutionsComponent;

  @Input() title: String;
  @Input() description: String;
  @Input() isAlternateRow: boolean;
   @Input() isFirstRow: boolean;

  errorContent: any;
  
  @Input() id: string;
   // State props
  @Input() state: ComponentStateType; // start with loader
  @Input() ready: boolean = true; // start with loader
  @Input() busy: boolean = true; // start with loader
  @Input() error: boolean = true; // start with loader

  @Input() minHeight: string = "200px";
  //  @Input() size: string; // xs = 4 col, sm = 3 col, md = 2 col, lg = 1 col
  @Input() border: string = "1px solid #ccc";
  @Input() seperator: string = "1px solid #ccc"
  @Input() spinner: string = "spin" // spin | circle | refresh | cog | pulse (default)
  @Input() spinnerColor: string = "#ccc";
  @Input() errorMessasge: string = '';

  @Output() clicked: EventEmitter<any> = new EventEmitter();

  spinnerClass: string = "fa-spinner fa-pulse";
  showBrokenIcon: boolean = false;
 public isShowDetail: boolean = false;

  constructor() { }

  ngOnInit() {

    switch (this.spinner) {
      case 'spin': this.spinnerClass = "fa-spinner"; break;
      case 'circle': this.spinnerClass = "fa-circle-o-notch"; break;
      case 'refresh': this.spinnerClass = "fa-refresh"; break;
      case 'cog': this.spinnerClass = "fa-cog"; break;
      default: this.spinnerClass = "fa-spinner fa-pulse";
    }
    this.state = new ComponentStateType();
    this.state.empty = true;
  }

 showDetails() {
      if (this.isFirstRow == true)
         this.isShowDetail = false;
      else
         this.isShowDetail = !this.isShowDetail;
      this.isFirstRow = false;

   }

  ngAfterViewInit() {
   
    if (this.errorContent) {
      this.showBrokenIcon = false;
    }
    else {
      this.showBrokenIcon = true;
    }
  }

  private handleTileClicked(): void {
    this.clicked.emit(this.id);
  }



  // Think of a good name
  // container?
  public SetState(state: ComponentStateType): void {
    if (!state.empty) this.state.empty = false;
    this.state = state;
  }

  public GetState(): ComponentStateType {
    return this.state;
  }

}

export class ComponentStateType {
  empty: boolean; // a component with no data
  loading: boolean; // a component waiting for data
  ready: boolean; // a component fully ready
  busy: boolean; // a component doing something
  error: boolean; // a component with error
  errorMessasge: string;

  public State(): string {
    if (this.empty) return 'empty';
    if (this.loading) return 'loading';
    if (this.busy) return 'busy';
    if (this.error) return 'error';
    return 'ready';
  }

}
