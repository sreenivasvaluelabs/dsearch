import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XdTablistComponent } from './xd-tablist.component';

describe('XdTablistComponent', () => {
  let component: XdTablistComponent;
  let fixture: ComponentFixture<XdTablistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XdTablistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XdTablistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
