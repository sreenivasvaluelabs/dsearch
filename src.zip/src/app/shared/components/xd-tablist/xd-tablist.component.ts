import { Component, OnInit, Input, Output, EventEmitter,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'xd-tablist',
  templateUrl: './xd-tablist.component.html',
  styleUrls: ['./xd-tablist.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class XdTablistComponent implements OnInit {

  @Input() xdTabList: any;

  @Input() orientation: string;

  @Input() tabSource : any;

  @Output() tabChange: EventEmitter<any> = new EventEmitter();
  selectedTab:any;
  
  constructor() { }

  ngOnInit() {
  }

  tabChanged(event : any){
    this.tabChange.emit(event.nextId);
  }

    showList = false;
    showDropdownList() {
      this.showList = !this.showList;
   }
   
}
