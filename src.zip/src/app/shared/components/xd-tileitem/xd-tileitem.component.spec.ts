import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XdTileItemComponent } from './xd-tileitem.component';

describe('XdTileItemComponent', () => {
  let component: XdTileItemComponent;
  let fixture: ComponentFixture<XdTileItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XdTileItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XdTileItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
