import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import * as models from './../../../service/_models/index';

@Component({
  selector: 'xd-tileitem',
  templateUrl: './xd-tileitem.component.html',
  styleUrls: ['./xd-tileitem.component.scss'],
   encapsulation: ViewEncapsulation.None
})
export class XdTileItemComponent implements OnInit {

  @Input() tileData :any;

  @Input() tileType : any;
  
  @Input() tileSource : any;

  constructor() { }

  ngOnInit() {
   
  }

}
