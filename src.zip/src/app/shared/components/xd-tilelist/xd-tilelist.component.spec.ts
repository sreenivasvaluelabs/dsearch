import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XdTileListComponent } from './xd-tilelist.component';

describe('XdTileListComponent', () => {
  let component: XdTileListComponent;
  let fixture: ComponentFixture<XdTileListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XdTileListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XdTileListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
