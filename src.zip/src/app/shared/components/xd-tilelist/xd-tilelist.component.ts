import { Component, OnInit, Input,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'xd-tilelist',
  templateUrl: './xd-tilelist.component.html',
  styleUrls: ['./xd-tilelist.component.scss'],
     encapsulation: ViewEncapsulation.None
})
export class XdTileListComponent implements OnInit {

  @Input() xdTileList: any;

  @Input() xdTileType: string;
  @Input() xdTileSource : string;

  constructor() { }

  ngOnInit() {
  }

}
