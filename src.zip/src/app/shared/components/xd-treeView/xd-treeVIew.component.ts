

import { Component, OnInit, Input, Output, EventEmitter,ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { BrowserModule } from '@angular/platform-browser';
@Component({
    selector: 'xd-treeView',
    templateUrl: './xd-treeView.component.html',
    styleUrls: ['./xd-treeView.scss'],
    encapsulation: ViewEncapsulation.None
})
export class XDTreeViewComponent implements OnInit {
    @Input() item: any;
    IsExpanded: boolean = false;

  constructor() { }

  ngOnInit() {
  }
  toggle() {
    this.IsExpanded = !this.IsExpanded;
    console.log(this.IsExpanded+" " + this.item.label);
    if(this.IsExpanded == true){
        
    }else{

    }
   }
   
}