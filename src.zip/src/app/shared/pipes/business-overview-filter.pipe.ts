import {Pipe, PipeTransform} from '@angular/core';

// Tell Angular2 we're creating a Pipe with TypeScript decorators
@Pipe({
  name: 'BusinessOverviewFilterPipe'
})
export class BusinessOverviewFilterPipe implements PipeTransform {

  // Transform is the new "return function(value, args)" in Angular 1.x
  transform(value : any, args? : any) {
    let tempArray = [];
    // ES6 array destructuring
    switch (args){
        case undefined : tempArray = value.filter((x:any) => x.title === 'Overview'); return tempArray; 
        case 'LOM View' : tempArray = value.filter((x:any) => x.title === args); return tempArray;
        case 'E2E View' : tempArray = value.filter((x:any) => x.title === args);  return tempArray;
    }
  }
}