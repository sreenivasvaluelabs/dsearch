import {Pipe, PipeTransform} from '@angular/core';

// Tell Angular2 we're creating a Pipe with TypeScript decorators
@Pipe({
  name: 'IndustryFilterPipe'
})
export class FilterPipe implements PipeTransform {

  // Transform is the new "return function(value, args)" in Angular 1.x
  transform(value : any, args? : any) {
      
    // ES6 array destructuring
    switch (args){
        case undefined : return value;
        case null : return value;
        case '' : return value;
        case 'All' : return value;
        default : let tempArray = value.filter((x:any) => x.description === args); return tempArray;
    }
  }
}