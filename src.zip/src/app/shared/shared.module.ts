import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';  //<<<< import it here
import { LoaderComponent } from './loader/loader.component';
import { HeaderComponent } from './components/header/header.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './components/footer/footer.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { TileComponent } from './components/tile/tile/tile.component';
import { TileContentComponent } from './components/tile/tile-content/tile-content.component';
import { TileHeaderComponent } from './components/tile/tile-header/tile-header.component';
import { BannerComponent } from './components/banner/banner.component';
import { XdTablistComponent } from './components/xd-tablist/xd-tablist.component';
import { XdTileListComponent } from './components/xd-tilelist/xd-tilelist.component';
import { XdTileItemComponent } from './components/xd-tileitem/xd-tileitem.component';
import { XdSectionComponent } from './components/xd-section/xd-section.component';
//import { IndustrySolutionsComponent } from '../modules/aieslanding-page/industry-solutions/industry-solutions.component';
import { QuicklinksComponent } from '../modules/aieslanding-page/quicklinks/quicklinks.component';
import { FilterPipe } from './pipes/industry-filter.pipe';
import { BusinessOverviewFilterPipe } from './pipes/business-overview-filter.pipe';
import { OrderrByPipe } from './pipes/orderby.pipe';
import { XDTreeViewComponent } from './components/xd-treeView/xd-treeVIew.component';
import { XdListComponent } from './components/xd-list/xd-list.component';
import { SearchFilterPipe} from './pipes/filter.pipe';
import{SortComponent} from  './components/xd-sort/xd-sort.component';
import{XDPagerComponent} from  './components/xd-pager/xd-pager.component';
import {XDSearchComponent} from './components/xd-search/xd-search.component';
@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    RouterModule,FormsModule
  ],
  declarations: [
    LoaderComponent,
    HeaderComponent,
    FooterComponent,
    CarouselComponent,
    TileComponent,
    TileContentComponent,
    TileHeaderComponent,
    BannerComponent,
    XdTablistComponent,XdTileListComponent,XdTileItemComponent,XdSectionComponent,SearchFilterPipe,XdListComponent,
    FilterPipe,QuicklinksComponent,BusinessOverviewFilterPipe,OrderrByPipe, XDTreeViewComponent,SortComponent,XDPagerComponent,XDSearchComponent
  ],
  exports: [
    LoaderComponent,
    HeaderComponent,
    FooterComponent,
    CarouselComponent,
    TileComponent,
    TileContentComponent,
    TileHeaderComponent,
    BannerComponent,
    XdTablistComponent,XdTileListComponent,XdTileItemComponent,XdSectionComponent,SearchFilterPipe,XdListComponent,
    FilterPipe,QuicklinksComponent,BusinessOverviewFilterPipe,OrderrByPipe, XDTreeViewComponent,SortComponent,XDPagerComponent,XDSearchComponent
  ]
})
export class SharedModule { }
