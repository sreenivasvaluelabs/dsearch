var myExtObject = (function() {
   
    var parentTermName;
    var termsMenuData={};
    var switchIndex = 0; 

    var deferred; 
    return {
      getBusinessProcessDataAll: function(subSiteName) {
       // alert('function 1 called');
        //console.log(subSiteName);
        // Taxonamy code will start here
        deferred = $.Deferred(); 
       
        parentTermName=subSiteName;
         //var scriptbase = _spPageContextInfo.webServerRelativeUrl + "/_layouts/15/"; // this code will work in SharePoint site only 
         var scriptbase = "https://avanade.sharepoint.com/Sites/AIES/_layouts/15/"
        // $.getScript(scriptbase + "SP.Runtime.js",
             // function () {
                  //$.getScript(scriptbase + "SP.js",
                   // function () { 
                        $.getScript(scriptbase + "SP.RequestExecutor.js",function () {                           
                             $.getScript(scriptbase + "SP.Taxonomy.js", LoadData);
                         });
                   // }
                //  );
             // }
      //  );	

        return deferred.promise();    

        // End of the Taxonomy code

      }
    } 

    function LoadData(){       
    
    var termSetName = parentTermName;   
    var locale = 1033; // your locale. Here is English 
    //console.log("Terms code started");
    var context  = SP.ClientContext.get_current();
    var taxonomySession = SP.Taxonomy.TaxonomySession.getTaxonomySession(context);
    var termStore = taxonomySession.getDefaultSiteCollectionTermStore();
    var termSets = termStore.getTermSetsByName(termSetName, locale);
    var termSet = termSets.getByName(termSetName);
    //var terms = termSet.getAllTerms();
    var terms = termSet.get_terms(); 
   // console.log("Terms Data will start");
    context.load(taxonomySession);
    context.load(termStore);
    context.load(termSet);
    context.load(terms);
    
    context.executeQueryAsync(
   
      function () {
       
        var arrChildTerms=[];
        var arrChildTermsnName=[];
        //console.log("Entered Success function");
        var termsEnum = terms.getEnumerator();	
        
        while (termsEnum.moveNext()) 
        {		 
          var currentTerm = termsEnum.get_current();	
          var path=currentTerm.get_pathOfTerm().split(';'); // what is the use 			
          var termName = currentTerm.get_name();			
        
            termsMenuData[termName]={};
        //Check if term has child terms
         
          if (currentTerm.get_termsCount() > 0) {
           
            var childterms = currentTerm.get_terms();
            arrChildTerms.push(childterms);
            arrChildTermsnName.push(termName);					
  
          }		 
        }			
   
        getNestedChildTerms(arrChildTerms,arrChildTermsnName,context);
              
      },		 
      function () {		 
        console.log("Error came");//failure to load terms.		 
      });
  }
      
  
function getNestedChildTerms(arrChildTerms,arrChildTermsnName,context){
		
		//var context = SP.ClientContext.get_current();
		var nestedArrChildTerms=[];	
		switchIndex = parseInt(switchIndex) + 1;

 		for(var i in arrChildTerms) context.load(arrChildTerms[i]);

		context.executeQueryAsync(function () {
			
			var nestedArrChildTermsNames=[];
			for(var j in arrChildTerms){
				
				var termsEnum = arrChildTerms[j].getEnumerator();
				var parentName=arrChildTermsnName[j];
				//var count=arrChildTermsnName[i].Count;
				
        var index=0;
				while (termsEnum.moveNext()) {
						index = index + 1;
					
					
          var newCurrentTerm = termsEnum.get_current();
						
					var termName = newCurrentTerm.get_name();
          
					switch(switchIndex){
								
								case 1:									
									termsMenuData[parentName][termName]={};		
								break;
								case 2:
									var strKey=parentName.split("@;&");
									termsMenuData[strKey[0]][strKey[1]][termName]={};								
								break;
								case 3:
									var strKey=parentName.split("@;&");									
									termsMenuData[strKey[0]][strKey[1]][strKey[2]][termName]={};							
								break;
								case 4:
									var strKey=parentName.split("@;&");
									termsMenuData[strKey[0]][strKey[1]][strKey[2]][strKey[3]][termName]={};
									break;
								default:
								break;								
							}			
					
					if (newCurrentTerm.get_termsCount() > 0) {
							var terms = newCurrentTerm.get_terms();
							nestedArrChildTerms.push(terms);
							nestedArrChildTermsNames.push(parentName+"@;&"+termName);						
					}	 
				}
		
			}		
      
    if(nestedArrChildTerms.length>0)
			getNestedChildTerms(nestedArrChildTerms,nestedArrChildTermsNames,context);
				
		else{	
      console.log("return code endded");
      console.log(termsMenuData);
			deferred.resolve(termsMenuData);			
		}
		 
		},function () { 
					//failure to load terms
		 
			});		
}

return {
      TestLoop: function() {
        alert('function 1 called');
      }
    }   
  
  })(myExtObject||{})